using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using BCrypt.Net;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;
using MySqlConnector;

namespace PorticoDesktop;

public sealed class MainWindow : Form
{
	private readonly WebView2 _webView;
	private Dictionary<string, string> _env = new();
	private int? _currentUserId;
	private string _currentNombre = string.Empty;
	private string _currentRol = string.Empty;

	public MainWindow()
	{
		Text = "Portico Desktop";
		var workingArea = Screen.PrimaryScreen?.WorkingArea ?? new System.Drawing.Rectangle(0, 0, 1280, 720);
		Width = Math.Min(1440, (int)(workingArea.Width * 0.9));
		Height = Math.Min(900, (int)(workingArea.Height * 0.9));
		MinimumSize = new System.Drawing.Size(1024, 680);
		StartPosition = FormStartPosition.CenterScreen;
		WindowState = FormWindowState.Maximized;

		var exePath = Application.ExecutablePath;
		if (File.Exists(exePath))
			Icon = Icon.ExtractAssociatedIcon(exePath);

		_webView = new WebView2
		{
			Dock = DockStyle.Fill
		};

		Controls.Add(_webView);
		Load += OnLoadAsync;
	}

	private async void OnLoadAsync(object? sender, EventArgs e)
	{
		try
		{
			_env = LoadEnv();

			await _webView.EnsureCoreWebView2Async();
			_webView.ZoomFactor = 1.0d;
			_webView.CoreWebView2.Settings.AreDevToolsEnabled = false;
			_webView.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;

			_webView.CoreWebView2.WebMessageReceived += OnWebMessageReceived;

			_webView.CoreWebView2.AddWebResourceRequestedFilter(
				"https://portico.desktop/*",
				CoreWebView2WebResourceContext.All);
			_webView.CoreWebView2.WebResourceRequested += OnWebResourceRequested;

			if (GetType().Assembly.GetManifestResourceStream("webui.Login.html") is null)
			{
				ShowError("No se encontró el recurso embebido webui.Login.html.");
				return;
			}

			_webView.Source = new Uri("https://portico.desktop/Login.html");
		}
		catch (WebView2RuntimeNotFoundException)
		{
			ShowError("No se encontró WebView2 Runtime. Instalá Microsoft Edge WebView2 Runtime.");
		}
		catch (Exception ex)
		{
			ShowError($"Error inicializando navegador: {ex.Message}");
		}
	}

	private async void OnWebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs args)
	{
		string responseType = "desktop_response";
		string requestId = string.Empty;

		try
		{
			var json = args.TryGetWebMessageAsString();
			using var doc  = JsonDocument.Parse(json);
			var root = doc.RootElement;

			if (!root.TryGetProperty("type", out var typeProp)) return;
			var messageType = typeProp.GetString() ?? string.Empty;
			requestId = root.TryGetProperty("requestId", out var requestIdProp)
				? requestIdProp.GetString() ?? string.Empty
				: string.Empty;
			responseType = string.IsNullOrWhiteSpace(messageType) ? responseType : $"{messageType}_response";

			switch (messageType)
			{
				case "login":
					await HandleLoginAsync(root);
					break;
				case "logout":
					HandleLogout();
					break;
				case "users_list":
					await HandleUsersListAsync(root);
					break;
				case "user_get":
					await HandleUserGetAsync(root);
					break;
				case "user_create":
					await HandleUserCreateAsync(root);
					break;
				case "user_update":
					await HandleUserUpdateAsync(root);
					break;
				case "user_delete":
					await HandleUserDeleteAsync(root);
					break;
				case "obras_listar":
					await HandleObrasListarAsync(root);
					break;
				case "obras_guardar":
					await HandleGuardarObraAsync(root);
					break;
				case "obras_eliminar":
					await HandleEliminarObraAsync(root);
					break;
			case "obras_descargar_contrato":
				await HandleDescargarContratoAsync(root);
				break;
			case "obras_detalle":
				await HandleObrasDetalleAsync(root);
				break;
			case "obras_cambiar_estado":
				await HandleObrasCambiarEstadoAsync(root);
				break;
			case "obreros_listar":
				await HandleObrerosListarAsync(root);
				break;
			case "obreros_guardar":
				await HandleGuardarObreroAsync(root);
				break;
			case "obreros_eliminar":
				await HandleEliminarObreroAsync(root);
				break;
			case "obreros_subir_contrato":
				await HandleObrerosSubirContratoAsync(root);
				break;
			case "obreros_contratos_listar":
				await HandleObrerosContratosListarAsync(root);
				break;
			case "obreros_contrato_descargar":
				await HandleObrerosContratoDescargarAsync(root);
				break;
			case "obreros_contrato_eliminar":
				await HandleObrerosContratoEliminarAsync(root);
				break;
			case "obreros_contrato_editar_fecha":
				await HandleObrerosContratoEditarFechaAsync(root);
				break;
			case "maquinaria_listar":
				await HandleMaquinariaListarAsync(root);
				break;
			case "maquinaria_guardar":
				await HandleGuardarMaquinariaAsync(root);
				break;
			case "maquinaria_eliminar":
				await HandleEliminarMaquinariaAsync(root);
				break;
			case "maquinaria_certificados_listar":
				await HandleMaquinariaCertificadosListarAsync(root);
				break;
			case "maquinaria_certificado_subir":
				await HandleMaquinariaCertificadoSubirAsync(root);
				break;
			case "maquinaria_certificado_descargar":
				await HandleMaquinariaCertificadoDescargarAsync(root);
				break;
			case "maquinaria_certificado_eliminar":
				await HandleMaquinariaCertificadoEliminarAsync(root);
				break;
			case "maquinaria_certificado_editar_fecha":
				await HandleMaquinariaCertificadoEditarFechaAsync(root);
				break;
			case "asistencia_catalogos":
				await HandleAsistenciaCatalogosAsync(root);
				break;
			case "asistencia_guardar":
				await HandleGuardarAsistenciaAsync(root);
				break;
			case "dashboard_metricas":
				await HandleDashboardMetricasAsync(root);
				break;
			case "notificacion_marcar_leida":
				await HandleNotificacionMarcarLeidaAsync(root);
				break;
			case "consultas_buscar":
				await HandleConsultasBuscarAsync(root);
				break;
			}
		}
		catch (Exception ex)
		{
			PostToJs(new { type = responseType, requestId, success = false, error = "Error interno del servidor." });
			// Log real error internally, never exponer al cliente
			System.Diagnostics.Debug.WriteLine($"[WebMessage error] {ex}");
		}
	}

	private async Task HandleLoginAsync(JsonElement root)
	{
		if (!root.TryGetProperty("usuario", out var usuarioProp) ||
		    !root.TryGetProperty("password", out var passwordProp))
		{
			PostToJs(new { type = "login_response", success = false, error = "Campos requeridos." });
			return;
		}

		var usuario  = usuarioProp.GetString()?.Trim() ?? "";
		var password = passwordProp.GetString() ?? "";

		if (usuario.Length == 0 || password.Length == 0 || usuario.Length > 50 || password.Length > 255)
		{
			PostToJs(new { type = "login_response", success = false, error = "Datos inválidos." });
			return;
		}

		try
		{
			var connString = BuildConnectionString();
			await using var conn = new MySqlConnection(connString);
			await conn.OpenAsync();

			// Prepared statement: sin interpolación de strings → inmune a SQL Injection
			await using var cmd = conn.CreateCommand();
			cmd.CommandText =
				"SELECT id_usuario, nombre, usuario, password_hash, rol, activo " +
				"FROM usuarios WHERE usuario = @usuario LIMIT 1";
			cmd.Parameters.AddWithValue("@usuario", usuario);

			await using var reader = await cmd.ExecuteReaderAsync();

			if (!await reader.ReadAsync())
			{
				// Usuario no existe — mismo mensaje genérico para no filtrar info
				PostToJs(new { type = "login_response", success = false, error = "Usuario o contraseña incorrectos." });
				return;
			}

			var activo       = Convert.ToInt32(reader["activo"]);
			var passwordHash = reader.GetString("password_hash");
			var idUsuario    = reader.GetInt32("id_usuario");
			var nombre       = reader.GetString("nombre");
			var rol          = reader.GetString("rol");

			// BCrypt.Net-Next verifica hashes $2y$ de PHP y $2a$ de C#
			var hashValido = BCrypt.Net.BCrypt.Verify(password, passwordHash);

			if (activo == 0 || !hashValido)
			{
				PostToJs(new { type = "login_response", success = false, error = "Usuario o contraseña incorrectos." });
				return;
			}

			_currentUserId = idUsuario;
			_currentNombre = nombre;
			_currentRol = rol;

			PostToJs(new { type = "login_response", success = true, user_id = idUsuario, nombre, rol });

			// Navegar según rol en el hilo de UI
			Invoke(() =>
			{
				var destino = rol == "Capataz" ? "Asistencia.html" : "PanelInicio.html";
				_webView.Source = new Uri($"https://portico.desktop/{destino}");
			});
		}
		catch (MySqlException ex)
		{
			System.Diagnostics.Debug.WriteLine($"[MySQL error] {ex}");
			PostToJs(new { type = "login_response", success = false, error = "No se pudo conectar a la base de datos." });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Login error] {ex}");
			PostToJs(new { type = "login_response", success = false, error = "Error interno del servidor." });
		}
	}

	private void HandleLogout()
	{
		_currentUserId = null;
		_currentNombre = string.Empty;
		_currentRol = string.Empty;

		PostToJs(new { type = "logout_response", success = true });

		Invoke(() =>
		{
			_webView.Source = new Uri("https://portico.desktop/Login.html");
		});
	}

	private async Task HandleAsistenciaCatalogosAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureCapatazOAdmin(requestId, "asistencia_catalogos_response"))
			return;

		try
		{
			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			var obras = new List<object>();
			await using (var cmd = conn.CreateCommand())
			{
				cmd.CommandText = "SELECT id_obra, nombre, numero_contrata FROM obras ORDER BY nombre ASC";
				await using var reader = await cmd.ExecuteReaderAsync();
				while (await reader.ReadAsync())
				{
					obras.Add(new
					{
						id = reader.GetInt32("id_obra"),
						nombre = reader.GetString("nombre"),
						numero_contrata = reader.GetString("numero_contrata")
					});
				}
			}

			var obreros = new List<object>();
			await using (var cmd = conn.CreateCommand())
			{
				cmd.CommandText = "SELECT id_obrero, nombre, apellido, documento FROM obreros WHERE activo = 1 ORDER BY nombre ASC, apellido ASC";
				await using var reader = await cmd.ExecuteReaderAsync();
				while (await reader.ReadAsync())
				{
					var apellidoOrdinal = reader.GetOrdinal("apellido");
					var apellido = reader.IsDBNull(apellidoOrdinal) ? string.Empty : reader.GetString("apellido");
					obreros.Add(new
					{
						id = reader.GetInt32("id_obrero"),
						nombre = string.Join(" ", new[] { reader.GetString("nombre"), apellido }.Where(static value => !string.IsNullOrWhiteSpace(value))),
						documento = reader.GetString("documento")
					});
				}
			}

			var materiales = await LeerRecursosAsync(conn, true);
			var herramientas = await LeerRecursosAsync(conn, false);

			var maquinaria = new List<object>();
			await using (var cmd = conn.CreateCommand())
			{
				cmd.CommandText = "SELECT id_maquinaria, nombre, marca FROM maquinaria ORDER BY nombre ASC";
				await using var reader = await cmd.ExecuteReaderAsync();
				while (await reader.ReadAsync())
				{
					maquinaria.Add(new
					{
						id_maquinaria = reader.GetInt32("id_maquinaria"),
						nombre = reader.GetString("nombre"),
						marca = ReadNullableString(reader, "marca")
					});
				}
			}

			PostToJs(new
			{
				type = "asistencia_catalogos_response",
				requestId,
				success = true,
				obras,
				obreros,
				materiales,
				herramientas,
				maquinaria
			});
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Asistencia catalogos error] {ex}");
			PostToJs(new { type = "asistencia_catalogos_response", requestId, success = false, error = "No se pudieron cargar los datos de asistencia." });
		}
	}

	private async Task HandleUsersListAsync(JsonElement root)
	{
		var requestId = ReadRequestId(root);
		const string responseType = "users_list_response";

		if (!EnsureAdministrador(requestId, responseType))
			return;

		try
		{
			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			var users = new List<object>();
			await using var cmd = conn.CreateCommand();
			cmd.CommandText = "SELECT id_usuario, nombre, usuario, rol, activo FROM usuarios ORDER BY id_usuario ASC";

			await using var reader = await cmd.ExecuteReaderAsync();
			while (await reader.ReadAsync())
			{
				users.Add(new
				{
					id_usuario = reader.GetInt32("id_usuario"),
					nombre = reader.GetString("nombre"),
					usuario = reader.GetString("usuario"),
					rol = reader.GetString("rol"),
					activo = Convert.ToInt32(reader["activo"])
				});
			}

			PostToJs(new { type = responseType, requestId, success = true, users });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Users list error] {ex}");
			PostToJs(new { type = responseType, requestId, success = false, error = "No se pudieron cargar los usuarios." });
		}
	}

	private async Task HandleUserGetAsync(JsonElement root)
	{
		var requestId = ReadRequestId(root);
		const string responseType = "user_get_response";

		if (!EnsureAdministrador(requestId, responseType))
			return;

		try
		{
			var idUsuario = ReadPositiveInt(root, "id_usuario");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			await using var cmd = conn.CreateCommand();
			cmd.CommandText = "SELECT id_usuario, nombre, usuario, rol, activo FROM usuarios WHERE id_usuario = @idUsuario LIMIT 1";
			cmd.Parameters.AddWithValue("@idUsuario", idUsuario);

			await using var reader = await cmd.ExecuteReaderAsync();
			if (!await reader.ReadAsync())
			{
				PostToJs(new { type = responseType, requestId, success = false, error = "Usuario no encontrado." });
				return;
			}

			PostToJs(new
			{
				type = responseType,
				requestId,
				success = true,
				user = new
				{
					id_usuario = reader.GetInt32("id_usuario"),
					nombre = reader.GetString("nombre"),
					usuario = reader.GetString("usuario"),
					rol = reader.GetString("rol"),
					activo = Convert.ToInt32(reader["activo"])
				}
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = responseType, requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[User get error] {ex}");
			PostToJs(new { type = responseType, requestId, success = false, error = "No se pudo cargar el usuario." });
		}
	}

	private async Task HandleUserCreateAsync(JsonElement root)
	{
		var requestId = ReadRequestId(root);
		const string responseType = "user_create_response";

		if (!EnsureAdministrador(requestId, responseType))
			return;

		try
		{
			var nombre = ReadRequiredString(root, "nombre");
			var usuario = ReadRequiredString(root, "usuario");
			var password = ReadPasswordString(root, "password", required: true);
			var rol = ReadRequiredString(root, "rol");

			ValidateUserFields(nombre, usuario, password, rol, validatePassword: true);

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			await using (var checkCmd = conn.CreateCommand())
			{
				checkCmd.CommandText = "SELECT id_usuario FROM usuarios WHERE usuario = @usuario LIMIT 1";
				checkCmd.Parameters.AddWithValue("@usuario", usuario);
				var existing = await checkCmd.ExecuteScalarAsync();
				if (existing is not null)
				{
					PostToJs(new { type = responseType, requestId, success = false, error = "El nombre de usuario ya está registrado." });
					return;
				}
			}

			await using var cmd = conn.CreateCommand();
			cmd.CommandText =
				"INSERT INTO usuarios (nombre, usuario, password_hash, rol, activo) VALUES (@nombre, @usuario, @passwordHash, @rol, 1); " +
				"SELECT LAST_INSERT_ID();";
			cmd.Parameters.AddWithValue("@nombre", nombre);
			cmd.Parameters.AddWithValue("@usuario", usuario);
			cmd.Parameters.AddWithValue("@passwordHash", BCrypt.Net.BCrypt.HashPassword(password));
			cmd.Parameters.AddWithValue("@rol", rol);

			var insertedId = Convert.ToInt32(await cmd.ExecuteScalarAsync());
			PostToJs(new
			{
				type = responseType,
				requestId,
				success = true,
				message = $"Usuario '{usuario}' creado correctamente.",
				user_id = insertedId
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = responseType, requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[User create error] {ex}");
			PostToJs(new { type = responseType, requestId, success = false, error = "No se pudo crear el usuario." });
		}
	}

	private async Task HandleUserUpdateAsync(JsonElement root)
	{
		var requestId = ReadRequestId(root);
		const string responseType = "user_update_response";

		if (!EnsureAdministrador(requestId, responseType))
			return;

		try
		{
			var idUsuario = ReadPositiveInt(root, "id_usuario");
			var nombre = ReadRequiredString(root, "nombre");
			var usuario = ReadRequiredString(root, "usuario");
			var rol = ReadRequiredString(root, "rol");
			var nuevaPassword = ReadPasswordString(root, "nueva_password", required: false);

			ValidateUserFields(nombre, usuario, nuevaPassword, rol, validatePassword: nuevaPassword.Length > 0);

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			await using (var existsCmd = conn.CreateCommand())
			{
				existsCmd.CommandText = "SELECT id_usuario FROM usuarios WHERE id_usuario = @idUsuario LIMIT 1";
				existsCmd.Parameters.AddWithValue("@idUsuario", idUsuario);
				var exists = await existsCmd.ExecuteScalarAsync();
				if (exists is null)
				{
					PostToJs(new { type = responseType, requestId, success = false, error = "Usuario no encontrado." });
					return;
				}
			}

			await using (var checkCmd = conn.CreateCommand())
			{
				checkCmd.CommandText = "SELECT id_usuario FROM usuarios WHERE usuario = @usuario AND id_usuario <> @idUsuario LIMIT 1";
				checkCmd.Parameters.AddWithValue("@usuario", usuario);
				checkCmd.Parameters.AddWithValue("@idUsuario", idUsuario);
				var existing = await checkCmd.ExecuteScalarAsync();
				if (existing is not null)
				{
					PostToJs(new { type = responseType, requestId, success = false, error = "El nombre de usuario ya está en uso por otra cuenta." });
					return;
				}
			}

			await using var cmd = conn.CreateCommand();
			if (nuevaPassword.Length > 0)
			{
				cmd.CommandText =
					"UPDATE usuarios SET nombre = @nombre, usuario = @usuario, rol = @rol, password_hash = @passwordHash WHERE id_usuario = @idUsuario";
				cmd.Parameters.AddWithValue("@passwordHash", BCrypt.Net.BCrypt.HashPassword(nuevaPassword));
			}
			else
			{
				cmd.CommandText = "UPDATE usuarios SET nombre = @nombre, usuario = @usuario, rol = @rol WHERE id_usuario = @idUsuario";
			}

			cmd.Parameters.AddWithValue("@nombre", nombre);
			cmd.Parameters.AddWithValue("@usuario", usuario);
			cmd.Parameters.AddWithValue("@rol", rol);
			cmd.Parameters.AddWithValue("@idUsuario", idUsuario);
			await cmd.ExecuteNonQueryAsync();

			PostToJs(new { type = responseType, requestId, success = true, message = "Usuario actualizado correctamente." });
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = responseType, requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[User update error] {ex}");
			PostToJs(new { type = responseType, requestId, success = false, error = "No se pudo actualizar el usuario." });
		}
	}

	private async Task HandleUserDeleteAsync(JsonElement root)
	{
		var requestId = ReadRequestId(root);
		const string responseType = "user_delete_response";

		if (!EnsureAdministrador(requestId, responseType))
			return;

		try
		{
			var idUsuario = ReadPositiveInt(root, "id_usuario");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			string? usuario, rol;
			await using (var selectCmd = conn.CreateCommand())
			{
				selectCmd.CommandText = "SELECT usuario, rol FROM usuarios WHERE id_usuario = @idUsuario LIMIT 1";
				selectCmd.Parameters.AddWithValue("@idUsuario", idUsuario);

				await using var reader = await selectCmd.ExecuteReaderAsync();
				if (!await reader.ReadAsync())
				{
					PostToJs(new { type = responseType, requestId, success = false, error = "Usuario no encontrado." });
					return;
				}

				usuario = reader.GetString("usuario");
				rol = reader.GetString("rol");
			}

			if (rol == "Administrador")
			{
				await using var countCmd = conn.CreateCommand();
				countCmd.CommandText = "SELECT COUNT(*) FROM usuarios WHERE rol = 'Administrador' AND activo = 1 AND id_usuario <> @idUsuario";
				countCmd.Parameters.AddWithValue("@idUsuario", idUsuario);
				var adminCount = Convert.ToInt32(await countCmd.ExecuteScalarAsync());
				if (adminCount < 1)
				{
					PostToJs(new { type = responseType, requestId, success = false, error = "No se puede desactivar el último administrador del sistema." });
					return;
				}
			}

			await using var updateCmd = conn.CreateCommand();
			updateCmd.CommandText = "UPDATE usuarios SET activo = 0 WHERE id_usuario = @idUsuario";
			updateCmd.Parameters.AddWithValue("@idUsuario", idUsuario);
			await updateCmd.ExecuteNonQueryAsync();

			PostToJs(new
			{
				type = responseType,
				requestId,
				success = true,
				message = $"Usuario '{usuario}' desactivado correctamente."
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = responseType, requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[User delete error] {ex}");
			PostToJs(new { type = responseType, requestId, success = false, error = "No se pudo desactivar el usuario." });
		}
	}

	private async Task HandleObrasListarAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAutenticado(requestId, "obras_listar_response"))
			return;

		try
		{
			var page = 1;
			if (root.TryGetProperty("page", out var pageProp))
			{
				if (pageProp.ValueKind == JsonValueKind.Number && pageProp.TryGetInt32(out var pageNumber) && pageNumber > 0)
					page = pageNumber;
				else if (pageProp.ValueKind == JsonValueKind.String && int.TryParse(pageProp.GetString(), out pageNumber) && pageNumber > 0)
					page = pageNumber;
			}

			var limit = 10;
			if (root.TryGetProperty("limit", out var limitProp))
			{
				if (limitProp.ValueKind == JsonValueKind.Number && limitProp.TryGetInt32(out var limitNumber) && limitNumber > 0)
					limit = limitNumber;
				else if (limitProp.ValueKind == JsonValueKind.String && int.TryParse(limitProp.GetString(), out limitNumber) && limitNumber > 0)
					limit = limitNumber;
			}
			limit = Math.Clamp(limit, 1, 100);

			var search = root.TryGetProperty("search", out var searchProp) && searchProp.ValueKind == JsonValueKind.String
				? searchProp.GetString()?.Trim() ?? string.Empty
				: string.Empty;
			var status = root.TryGetProperty("status", out var statusProp) && statusProp.ValueKind == JsonValueKind.String
				? (statusProp.GetString()?.Trim().ToLowerInvariant() ?? "all")
				: "all";

			if (status is not ("all" or "active" or "inactive"))
				throw new InvalidOperationException("Filtro de estado inválido.");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			var where = new List<string>();
			var countParams = new List<MySqlParameter>();

			if (!string.IsNullOrWhiteSpace(search))
			{
				where.Add("(o.numero_contrata LIKE @search OR o.nombre LIKE @search OR o.direccion LIKE @search OR o.descripcion LIKE @search OR o.nombre_cliente LIKE @search OR o.telefono_cliente LIKE @search)");
				countParams.Add(new MySqlParameter("@search", $"%{search}%"));
			}

			if (status == "active")
				where.Add("o.activo = 1");
			else if (status == "inactive")
				where.Add("o.activo = 0");

			var whereSql = where.Count > 0 ? " WHERE " + string.Join(" AND ", where) : string.Empty;

			var total = 0;
			await using (var countCmd = conn.CreateCommand())
			{
				countCmd.CommandText = "SELECT COUNT(*) FROM obras o" + whereSql;
				foreach (var param in countParams)
					countCmd.Parameters.AddWithValue(param.ParameterName, param.Value);

				total = Convert.ToInt32(await countCmd.ExecuteScalarAsync());
			}

			var totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)limit));
			page = Math.Min(page, totalPages);
			var offset = (page - 1) * limit;

			var obras = new List<object>();
			await using var cmd = conn.CreateCommand();
			cmd.CommandText =
				"SELECT o.id_obra, o.numero_contrata, o.nombre, o.direccion, o.descripcion, o.fecha_inicio, o.fecha_fin, o.nombre_cliente, o.telefono_cliente, o.activo, " +
				"c.nombre_archivo AS contrato_nombre_archivo " +
				"FROM obras o " +
				"LEFT JOIN (" +
				"SELECT c1.id_obra, c1.nombre_archivo FROM contratos c1 " +
				"INNER JOIN (SELECT id_obra, MAX(id_contrato) AS max_id_contrato FROM contratos GROUP BY id_obra) ult " +
				"ON ult.id_obra = c1.id_obra AND ult.max_id_contrato = c1.id_contrato" +
				") c ON c.id_obra = o.id_obra " +
				whereSql +
				" ORDER BY o.fecha_inicio DESC, o.nombre ASC LIMIT @limit OFFSET @offset";
			foreach (var param in countParams)
				cmd.Parameters.AddWithValue(param.ParameterName, param.Value);
			cmd.Parameters.AddWithValue("@limit", limit);
			cmd.Parameters.AddWithValue("@offset", offset);

			await using var reader = await cmd.ExecuteReaderAsync();
			while (await reader.ReadAsync())
			{
				obras.Add(MapObra(reader));
			}

			PostToJs(new
			{
				type = "obras_listar_response",
				requestId,
				success = true,
				obras,
				total,
				page,
				per_page = limit,
				total_pages = totalPages
			});
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Obras listar error] {ex}");
			PostToJs(new { type = "obras_listar_response", requestId, success = false, error = "No se pudieron cargar las obras." });
		}
	}

	private async Task HandleGuardarObraAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAdministrador(requestId, "obras_guardar_response"))
			return;

		try
		{
			var payload = ValidateObraPayload(root);
			var contrato = ReadContrato(root);
			var idObra = TryReadPositiveInt(root, "id_obra");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();
			await using var tx = await conn.BeginTransactionAsync();

			if (idObra.HasValue)
			{
				if (!await ObraExistsAsync(conn, idObra.Value))
					throw new InvalidOperationException("La obra indicada no existe.");

				await using var updateCmd = conn.CreateCommand();
				updateCmd.Transaction = tx;
				updateCmd.CommandText =
					"UPDATE obras SET numero_contrata = @numeroContrata, nombre = @nombre, direccion = @direccion, descripcion = @descripcion, " +
					"fecha_inicio = @fechaInicio, fecha_fin = @fechaFin, nombre_cliente = @nombreCliente, telefono_cliente = @telefonoCliente " +
					"WHERE id_obra = @idObra";
				AddObraParameters(updateCmd, payload, idObra.Value);
				await updateCmd.ExecuteNonQueryAsync();

				if (contrato is not null)
					await GuardarContratoAsync(conn, tx, idObra.Value, contrato.Value.NombreArchivo, contrato.Value.Archivo);

				await tx.CommitAsync();

				var obra = await GetObraByIdAsync(conn, idObra.Value);
				PostToJs(new
				{
					type = "obras_guardar_response",
					requestId,
					success = true,
					message = "Obra actualizada correctamente.",
					obra
				});
				return;
			}

			var nuevaId = 0;
			await using (var insertCmd = conn.CreateCommand())
			{
				insertCmd.Transaction = tx;
				insertCmd.CommandText =
					"INSERT INTO obras (numero_contrata, nombre, direccion, descripcion, fecha_inicio, fecha_fin, nombre_cliente, telefono_cliente) " +
					"VALUES (@numeroContrata, @nombre, @direccion, @descripcion, @fechaInicio, @fechaFin, @nombreCliente, @telefonoCliente)";
				AddObraParameters(insertCmd, payload, null);
				await insertCmd.ExecuteNonQueryAsync();
				nuevaId = Convert.ToInt32(insertCmd.LastInsertedId);
			}

			if (contrato is not null)
				await GuardarContratoAsync(conn, tx, nuevaId, contrato.Value.NombreArchivo, contrato.Value.Archivo);

			await tx.CommitAsync();

			var nuevaObra = await GetObraByIdAsync(conn, nuevaId);
			PostToJs(new
			{
				type = "obras_guardar_response",
				requestId,
				success = true,
				message = "Obra guardada correctamente.",
				obra = nuevaObra
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "obras_guardar_response", requestId, success = false, error = ex.Message });
		}
		catch (MySqlException ex) when (ex.Number == 1062)
		{
			PostToJs(new { type = "obras_guardar_response", requestId, success = false, error = "El número de contrata ya existe." });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Obras guardar error] {ex}");
			PostToJs(new { type = "obras_guardar_response", requestId, success = false, error = "No se pudo guardar la obra." });
		}
	}

	private async Task HandleEliminarObraAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAdministrador(requestId, "obras_eliminar_response"))
			return;

		try
		{
			var idObra = ReadPositiveInt(root, "id_obra");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			await using var cmd = conn.CreateCommand();
			cmd.CommandText = "DELETE FROM obras WHERE id_obra = @idObra";
			cmd.Parameters.AddWithValue("@idObra", idObra);
			var affected = await cmd.ExecuteNonQueryAsync();

			if (affected == 0)
				throw new InvalidOperationException("La obra indicada no existe.");

			PostToJs(new
			{
				type = "obras_eliminar_response",
				requestId,
				success = true,
				message = "Obra eliminada correctamente."
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "obras_eliminar_response", requestId, success = false, error = ex.Message });
		}
		catch (MySqlException ex) when (ex.Number == 1451)
		{
			PostToJs(new { type = "obras_eliminar_response", requestId, success = false, error = "No se puede eliminar la obra porque tiene registros asociados." });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Obras eliminar error] {ex}");
			PostToJs(new { type = "obras_eliminar_response", requestId, success = false, error = "No se pudo eliminar la obra." });
		}
	}

	private async Task HandleDescargarContratoAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAdministrador(requestId, "obras_descargar_contrato_response"))
			return;

		try
		{
			var idObra = ReadPositiveInt(root, "id_obra");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			await using var cmd = conn.CreateCommand();
			cmd.CommandText =
				"SELECT nombre_archivo, archivo FROM contratos WHERE id_obra = @idObra ORDER BY id_contrato DESC LIMIT 1";
			cmd.Parameters.AddWithValue("@idObra", idObra);

			await using var reader = await cmd.ExecuteReaderAsync(System.Data.CommandBehavior.SequentialAccess);
			if (!await reader.ReadAsync())
				throw new InvalidOperationException("La obra no tiene contrato cargado.");

			var nombreArchivo = ReadNullableString(reader, "nombre_archivo") ?? $"contrato-{idObra}";
			var archivoOrdinal = reader.GetOrdinal("archivo");
			var archivo = (byte[])reader.GetValue(archivoOrdinal);

			PostToJs(new
			{
				type = "obras_descargar_contrato_response",
				requestId,
				success = true,
				nombre_archivo = nombreArchivo,
				tipo_contenido = GuessMimeType(nombreArchivo),
				contenido_base64 = Convert.ToBase64String(archivo)
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "obras_descargar_contrato_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Obras descargar contrato error] {ex}");
			PostToJs(new { type = "obras_descargar_contrato_response", requestId, success = false, error = "No se pudo descargar el contrato." });
		}
	}

	private async Task HandleObrerosListarAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAutenticado(requestId, "obreros_listar_response"))
			return;

		try
		{
			var page = 1;
			if (root.TryGetProperty("page", out var pageProp))
			{
				if (pageProp.ValueKind == JsonValueKind.Number && pageProp.TryGetInt32(out var pageNumber) && pageNumber > 0)
					page = pageNumber;
				else if (pageProp.ValueKind == JsonValueKind.String && int.TryParse(pageProp.GetString(), out pageNumber) && pageNumber > 0)
					page = pageNumber;
			}

			var limit = 10;
			if (root.TryGetProperty("limit", out var limitProp))
			{
				if (limitProp.ValueKind == JsonValueKind.Number && limitProp.TryGetInt32(out var limitNumber) && limitNumber > 0)
					limit = limitNumber;
				else if (limitProp.ValueKind == JsonValueKind.String && int.TryParse(limitProp.GetString(), out limitNumber) && limitNumber > 0)
					limit = limitNumber;
			}
			limit = Math.Clamp(limit, 1, 100);

			var search = root.TryGetProperty("search", out var searchProp) && searchProp.ValueKind == JsonValueKind.String
				? (searchProp.GetString()?.Trim() ?? string.Empty)
				: string.Empty;

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			var where = new List<string> { "activo = 1" };
			var countParams = new List<MySqlParameter>();

			if (!string.IsNullOrWhiteSpace(search))
			{
				where.Add("(nombre LIKE @search OR apellido LIKE @search OR documento LIKE @search OR telefono LIKE @search)");
				countParams.Add(new MySqlParameter("@search", $"%{search}%"));
			}

			var whereSql = " WHERE " + string.Join(" AND ", where);

			var total = 0;
			await using (var countCmd = conn.CreateCommand())
			{
				countCmd.CommandText = "SELECT COUNT(*) FROM obreros" + whereSql;
				foreach (var param in countParams)
					countCmd.Parameters.AddWithValue(param.ParameterName, param.Value);
				total = Convert.ToInt32(await countCmd.ExecuteScalarAsync());
			}

			var totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)limit));
			page = Math.Min(page, totalPages);
			var offset = (page - 1) * limit;

			await using var cmd = conn.CreateCommand();
			cmd.CommandText =
				"SELECT o.id_obrero, o.nombre, o.apellido, o.documento, o.telefono, o.fecha_contratacion, o.fecha_fin, o.cargo, " +
				"(SELECT c.fecha_vencimiento FROM contrato_obrero c WHERE c.id_obrero = o.id_obrero ORDER BY c.fecha_vencimiento DESC LIMIT 1) AS vencimiento " +
				"FROM obreros o"
				+ whereSql
				+ " ORDER BY o.id_obrero DESC LIMIT @limit OFFSET @offset";

			foreach (var param in countParams)
				cmd.Parameters.AddWithValue(param.ParameterName, param.Value);
			cmd.Parameters.AddWithValue("@limit", limit);
			cmd.Parameters.AddWithValue("@offset", offset);

			var obreros = new List<object>();
			await using var reader = await cmd.ExecuteReaderAsync();
			while (await reader.ReadAsync())
			{
				obreros.Add(new
				{
					id_obrero = reader.GetInt32("id_obrero"),
					nombre = reader.GetString("nombre"),
					apellido = ReadNullableString(reader, "apellido"),
					documento = reader.GetString("documento"),
					telefono = ReadNullableString(reader, "telefono"),
					fecha_contratacion = ReadNullableDate(reader, "fecha_contratacion"),
					fecha_fin = ReadNullableDate(reader, "fecha_fin"),
					cargo = ReadNullableString(reader, "cargo") ?? "Peón",
					vencimiento = ReadNullableDate(reader, "vencimiento")
				});
			}

			PostToJs(new
			{
				type = "obreros_listar_response",
				requestId,
				success = true,
				obreros,
				total,
				page,
				per_page = limit,
				total_pages = totalPages
			});
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Obreros listar error] {ex}");
			PostToJs(new { type = "obreros_listar_response", requestId, success = false, error = "No se pudieron cargar los obreros." });
		}
	}

	private async Task HandleGuardarObreroAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAdministrador(requestId, "obreros_guardar_response"))
			return;

		try
		{
			var nombre = ReadRequiredString(root, "nombre");
			var apellido = root.TryGetProperty("apellido", out var apellidoProp) && apellidoProp.ValueKind == JsonValueKind.String
				? (apellidoProp.GetString()?.Trim() ?? string.Empty)
				: string.Empty;
			var documento = ReadRequiredString(root, "documento");
			var telefono = root.TryGetProperty("telefono", out var telefonoProp) && telefonoProp.ValueKind == JsonValueKind.String
				? (telefonoProp.GetString()?.Trim() ?? string.Empty)
				: string.Empty;
			var fechaContratacion = root.TryGetProperty("fecha_contratacion", out var fechaProp) && fechaProp.ValueKind == JsonValueKind.String
				? (fechaProp.GetString()?.Trim() ?? string.Empty)
				: string.Empty;
			var fechaFin = root.TryGetProperty("fecha_fin", out var fechaFinProp) && fechaFinProp.ValueKind == JsonValueKind.String
				? (fechaFinProp.GetString()?.Trim() ?? string.Empty)
				: string.Empty;
			var idObrero = TryReadPositiveInt(root, "id_obrero");

			if (nombre.Length > 150)
				throw new InvalidOperationException("El nombre es demasiado largo.");
			if (apellido.Length > 100)
				throw new InvalidOperationException("El apellido es demasiado largo.");
			if (documento.Length > 30)
				throw new InvalidOperationException("El documento es demasiado largo.");
			if (telefono.Length > 30)
				throw new InvalidOperationException("El teléfono es demasiado largo.");

			string? fechaDb = null;
			if (!string.IsNullOrWhiteSpace(fechaContratacion))
			{
				if (!DateTime.TryParseExact(fechaContratacion, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _))
					throw new InvalidOperationException("Formato de fecha inválido.");
				fechaDb = fechaContratacion;
			}

			string? fechaFinDb = null;
			if (!string.IsNullOrWhiteSpace(fechaFin))
			{
				if (!DateTime.TryParseExact(fechaFin, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _))
					throw new InvalidOperationException("Formato de fecha de fin inválido.");
				fechaFinDb = fechaFin;
			}

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();
			await using var tx = await conn.BeginTransactionAsync();

			if (idObrero.HasValue)
			{
				await using (var existsCmd = conn.CreateCommand())
				{
					existsCmd.Transaction = tx;
					existsCmd.CommandText = "SELECT id_obrero FROM obreros WHERE id_obrero = @idObrero LIMIT 1";
					existsCmd.Parameters.AddWithValue("@idObrero", idObrero.Value);
					var exists = await existsCmd.ExecuteScalarAsync();
					if (exists is null)
						throw new InvalidOperationException("El obrero indicado no existe.");
				}

				await using (var dupCmd = conn.CreateCommand())
				{
					dupCmd.Transaction = tx;
					dupCmd.CommandText = "SELECT id_obrero FROM obreros WHERE documento = @documento AND id_obrero <> @idObrero LIMIT 1";
					dupCmd.Parameters.AddWithValue("@documento", documento);
					dupCmd.Parameters.AddWithValue("@idObrero", idObrero.Value);
					var dup = await dupCmd.ExecuteScalarAsync();
					if (dup is not null)
						throw new InvalidOperationException("Ya existe otro obrero con ese documento.");
				}

				await using var updateCmd = conn.CreateCommand();
				updateCmd.Transaction = tx;
				updateCmd.CommandText =
					"UPDATE obreros SET nombre = @nombre, apellido = @apellido, documento = @documento, telefono = @telefono, fecha_contratacion = @fecha, fecha_fin = @fechaFin WHERE id_obrero = @idObrero";
				updateCmd.Parameters.AddWithValue("@nombre", nombre);
				updateCmd.Parameters.AddWithValue("@apellido", string.IsNullOrWhiteSpace(apellido) ? DBNull.Value : apellido);
				updateCmd.Parameters.AddWithValue("@documento", documento);
				updateCmd.Parameters.AddWithValue("@telefono", string.IsNullOrWhiteSpace(telefono) ? DBNull.Value : telefono);
				updateCmd.Parameters.AddWithValue("@fecha", fechaDb is null ? DBNull.Value : fechaDb);
				updateCmd.Parameters.AddWithValue("@fechaFin", fechaFinDb is null ? DBNull.Value : fechaFinDb);
				updateCmd.Parameters.AddWithValue("@idObrero", idObrero.Value);
				await updateCmd.ExecuteNonQueryAsync();

				await tx.CommitAsync();

				PostToJs(new
				{
					type = "obreros_guardar_response",
					requestId,
					success = true,
					message = "Obrero actualizado correctamente."
				});
				return;
			}

			await using (var dupCmd = conn.CreateCommand())
			{
				dupCmd.Transaction = tx;
				dupCmd.CommandText = "SELECT id_obrero FROM obreros WHERE documento = @documento LIMIT 1";
				dupCmd.Parameters.AddWithValue("@documento", documento);
				var dup = await dupCmd.ExecuteScalarAsync();
				if (dup is not null)
					throw new InvalidOperationException("Ya existe un obrero con ese documento.");
			}

			await using var insertCmd = conn.CreateCommand();
			insertCmd.Transaction = tx;
			insertCmd.CommandText =
				"INSERT INTO obreros (nombre, apellido, documento, telefono, fecha_contratacion, fecha_fin, activo) VALUES (@nombre, @apellido, @documento, @telefono, @fecha, @fechaFin, 1)";
			insertCmd.Parameters.AddWithValue("@nombre", nombre);
			insertCmd.Parameters.AddWithValue("@apellido", string.IsNullOrWhiteSpace(apellido) ? DBNull.Value : apellido);
			insertCmd.Parameters.AddWithValue("@documento", documento);
			insertCmd.Parameters.AddWithValue("@telefono", string.IsNullOrWhiteSpace(telefono) ? DBNull.Value : telefono);
			insertCmd.Parameters.AddWithValue("@fecha", fechaDb is null ? DBNull.Value : fechaDb);
			insertCmd.Parameters.AddWithValue("@fechaFin", fechaFinDb is null ? DBNull.Value : fechaFinDb);
			await insertCmd.ExecuteNonQueryAsync();

			await tx.CommitAsync();

			PostToJs(new
			{
				type = "obreros_guardar_response",
				requestId,
				success = true,
				message = "Obrero registrado correctamente."
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "obreros_guardar_response", requestId, success = false, error = ex.Message });
		}
		catch (MySqlException ex) when (ex.Number == 1062)
		{
			PostToJs(new { type = "obreros_guardar_response", requestId, success = false, error = "Ya existe un obrero con ese documento." });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Obreros guardar error] {ex}");
			PostToJs(new { type = "obreros_guardar_response", requestId, success = false, error = "No se pudo guardar el obrero." });
		}
	}

	private async Task HandleEliminarObreroAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAdministrador(requestId, "obreros_eliminar_response"))
			return;

		try
		{
			var idObrero = ReadPositiveInt(root, "id_obrero");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			await using var cmd = conn.CreateCommand();
			cmd.CommandText = "UPDATE obreros SET activo = 0 WHERE id_obrero = @idObrero";
			cmd.Parameters.AddWithValue("@idObrero", idObrero);
			var affected = await cmd.ExecuteNonQueryAsync();

			if (affected == 0)
				throw new InvalidOperationException("El obrero indicado no existe.");

			PostToJs(new
			{
				type = "obreros_eliminar_response",
				requestId,
				success = true,
				message = "Obrero eliminado correctamente."
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "obreros_eliminar_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Obreros eliminar error] {ex}");
			PostToJs(new { type = "obreros_eliminar_response", requestId, success = false, error = "No se pudo eliminar el obrero." });
		}
	}

	private async Task HandleObrasDetalleAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAutenticado(requestId, "obras_detalle_response"))
			return;

		try
		{
			var idObra = ReadPositiveInt(root, "id_obra");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			var obra = await GetObraByIdAsync(conn, idObra);

			var materiales = new List<object>();
			await using (var cmd = conn.CreateCommand())
			{
				cmd.CommandText =
					"SELECT nombre, SUM(cantidad) as cantidad_total, SUM(cantidad * COALESCE(precio_unitario, 0)) as costo_total " +
					"FROM recursos WHERE id_obra = @idObra AND es_material = 1 GROUP BY nombre ORDER BY nombre";
				cmd.Parameters.AddWithValue("@idObra", idObra);
				await using var reader = await cmd.ExecuteReaderAsync();
				while (await reader.ReadAsync())
				{
					materiales.Add(new
					{
						nombre = reader.GetString("nombre"),
						cantidad_total = reader.GetDecimal("cantidad_total"),
						costo_total = reader.IsDBNull(reader.GetOrdinal("costo_total")) ? 0m : reader.GetDecimal("costo_total")
					});
				}
			}

			var herramientas = new List<object>();
			await using (var cmd = conn.CreateCommand())
			{
				cmd.CommandText =
					"SELECT nombre, SUM(cantidad) as cantidad_total " +
					"FROM recursos WHERE id_obra = @idObra AND es_material = 0 GROUP BY nombre ORDER BY nombre";
				cmd.Parameters.AddWithValue("@idObra", idObra);
				await using var reader = await cmd.ExecuteReaderAsync();
				while (await reader.ReadAsync())
				{
					herramientas.Add(new
					{
						nombre = reader.GetString("nombre"),
						cantidad_total = reader.GetDecimal("cantidad_total")
					});
				}
			}

			var obreros = new List<object>();
			await using (var cmd = conn.CreateCommand())
			{
				cmd.CommandText =
					"SELECT obr.id_obrero, obr.nombre, obr.apellido, SUM(reg.horas_trabajadas) as horas_totales " +
					"FROM registros reg INNER JOIN obreros obr ON obr.id_obrero = reg.id_obrero " +
					"WHERE reg.id_obra = @idObra GROUP BY obr.id_obrero, obr.nombre, obr.apellido ORDER BY obr.apellido, obr.nombre";
				cmd.Parameters.AddWithValue("@idObra", idObra);
				await using var reader = await cmd.ExecuteReaderAsync();
				while (await reader.ReadAsync())
				{
					obreros.Add(new
					{
						id_obrero = reader.GetInt32("id_obrero"),
						nombre = reader.GetString("nombre"),
						apellido = ReadNullableString(reader, "apellido"),
						horas_totales = reader.GetDecimal("horas_totales")
					});
				}
			}

			var maquinaria = new List<object>();
			await using (var cmd = conn.CreateCommand())
			{
				cmd.CommandText =
					"SELECT m.nombre, m.marca, om.fecha_asignacion, om.fecha_retiro " +
					"FROM obra_maquinaria om INNER JOIN maquinaria m ON m.id_maquinaria = om.id_maquinaria " +
					"WHERE om.id_obra = @idObra ORDER BY om.fecha_asignacion DESC, m.nombre";
				cmd.Parameters.AddWithValue("@idObra", idObra);
				await using var reader = await cmd.ExecuteReaderAsync();
				while (await reader.ReadAsync())
				{
					maquinaria.Add(new
					{
						nombre = reader.GetString("nombre"),
						marca = ReadNullableString(reader, "marca"),
						fecha_asignacion = ReadNullableDate(reader, "fecha_asignacion"),
						fecha_retiro = ReadNullableDate(reader, "fecha_retiro")
					});
				}
			}

			var tareas = new List<object>();
			await using (var cmd = conn.CreateCommand())
			{
				cmd.CommandText =
					"SELECT ct.id_tarea, ct.id_contrato, ct.id_tarea_origen, ct.descripcion, ct.importe, ct.estado, ct.fecha_completada " +
					"FROM contrato_tareas ct INNER JOIN contratos c ON c.id_contrato = ct.id_contrato " +
					"WHERE c.id_obra = @idObra ORDER BY ct.id_tarea ASC";
				cmd.Parameters.AddWithValue("@idObra", idObra);
				await using var reader = await cmd.ExecuteReaderAsync();
				while (await reader.ReadAsync())
				{
					tareas.Add(new
					{
						id_tarea = reader.GetInt32("id_tarea"),
						id_contrato = reader.GetInt32("id_contrato"),
						id_tarea_origen = reader.IsDBNull(reader.GetOrdinal("id_tarea_origen")) ? (int?)null : reader.GetInt32("id_tarea_origen"),
						descripcion = reader.GetString("descripcion"),
						importe = reader.GetDecimal("importe"),
						estado = reader.GetString("estado"),
						fecha_completada = ReadNullableDate(reader, "fecha_completada")
					});
				}
			}

			var combustible = new List<object>();
			await using (var cmd = conn.CreateCommand())
			{
				cmd.CommandText =
					"SELECT c.id_combustible, c.fecha, c.nombre_combustible, c.litros, c.precio_unitario, c.precio_total, " +
					"COALESCE(m.nombre, 'Sin asignar') as maquinaria_nombre, m.marca as maquinaria_marca " +
					"FROM combustible c LEFT JOIN maquinaria m ON m.id_maquinaria = c.id_maquinaria " +
					"WHERE c.id_obra = @idObra ORDER BY c.fecha DESC, c.id_combustible DESC";
				cmd.Parameters.AddWithValue("@idObra", idObra);
				await using var reader = await cmd.ExecuteReaderAsync();
				while (await reader.ReadAsync())
				{
					combustible.Add(new
					{
						id_combustible = reader.GetInt32("id_combustible"),
						fecha = ReadNullableDate(reader, "fecha"),
						nombre_combustible = reader.GetString("nombre_combustible"),
						litros = reader.GetDecimal("litros"),
						precio_unitario = reader.GetDecimal("precio_unitario"),
						precio_total = reader.GetDecimal("precio_total"),
						maquinaria_nombre = reader.GetString("maquinaria_nombre"),
						maquinaria_marca = ReadNullableString(reader, "maquinaria_marca")
					});
				}
			}

			PostToJs(new
			{
				type = "obras_detalle_response",
				requestId,
				success = true,
				obra,
				materiales,
				herramientas,
				obreros,
				maquinaria,
				combustible,
				tareas
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "obras_detalle_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Obras detalle error] {ex}");
			PostToJs(new { type = "obras_detalle_response", requestId, success = false, error = "No se pudo cargar el detalle de la obra." });
		}
	}

	private async Task HandleObrasCambiarEstadoAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAdministrador(requestId, "obras_cambiar_estado_response"))
			return;

		try
		{
			var idObra = ReadPositiveInt(root, "id_obra");
			var activo = ReadPositiveInt(root, "activo");
			if (activo != 0 && activo != 1)
				throw new InvalidOperationException("El estado debe ser 0 o 1.");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			await using var cmd = conn.CreateCommand();
			cmd.CommandText = "UPDATE obras SET activo = @activo WHERE id_obra = @idObra";
			cmd.Parameters.AddWithValue("@activo", activo);
			cmd.Parameters.AddWithValue("@idObra", idObra);
			var affected = await cmd.ExecuteNonQueryAsync();

			if (affected == 0)
				throw new InvalidOperationException("No se pudo actualizar la obra o ya tenía ese estado.");

			PostToJs(new
			{
				type = "obras_cambiar_estado_response",
				requestId,
				success = true,
				message = "Estado de la obra actualizado correctamente."
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "obras_cambiar_estado_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Obras cambiar estado error] {ex}");
			PostToJs(new { type = "obras_cambiar_estado_response", requestId, success = false, error = "No se pudo cambiar el estado de la obra." });
		}
	}

	private async Task HandleObrerosSubirContratoAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAdministrador(requestId, "obreros_subir_contrato_response"))
			return;

		try
		{
			var idObrero = ReadPositiveInt(root, "id_obrero");
			var fechaVencimiento = ReadRequiredString(root, "fecha_vencimiento");
			var nombreArchivo = ReadRequiredString(root, "nombre_archivo");
			var contenidoBase64 = ReadRequiredString(root, "contenido_base64");

			if (!DateTime.TryParseExact(fechaVencimiento, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _))
				throw new InvalidOperationException("Formato de fecha inválido.");

			byte[] archivo;
			try
			{
				archivo = Convert.FromBase64String(contenidoBase64);
			}
			catch (FormatException)
			{
				throw new InvalidOperationException("El archivo seleccionado es inválido.");
			}

			if (archivo.Length > 10 * 1024 * 1024)
				throw new InvalidOperationException("El contrato no puede superar los 10 MB.");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			await using var cmd = conn.CreateCommand();
			cmd.CommandText =
				"INSERT INTO contrato_obrero (archivo, nombre_archivo, id_obrero, fecha_vencimiento) VALUES (@archivo, @nombreArchivo, @idObrero, @fechaVencimiento)";
			cmd.Parameters.Add("@archivo", MySqlDbType.LongBlob).Value = archivo;
			cmd.Parameters.AddWithValue("@nombreArchivo", nombreArchivo);
			cmd.Parameters.AddWithValue("@idObrero", idObrero);
			cmd.Parameters.AddWithValue("@fechaVencimiento", fechaVencimiento);
			await cmd.ExecuteNonQueryAsync();

			PostToJs(new
			{
				type = "obreros_subir_contrato_response",
				requestId,
				success = true,
				message = "Contrato subido correctamente."
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "obreros_subir_contrato_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Obreros subir contrato error] {ex}");
			PostToJs(new { type = "obreros_subir_contrato_response", requestId, success = false, error = "No se pudo subir el contrato." });
		}
	}

	private async Task HandleObrerosContratosListarAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAutenticado(requestId, "obreros_contratos_listar_response"))
			return;

		try
		{
			var idObrero = ReadPositiveInt(root, "id_obrero");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			var contratos = new List<object>();
			await using (var cmd = conn.CreateCommand())
			{
				cmd.CommandText = "SELECT id_contrato_obrero, nombre_archivo, fecha_vencimiento FROM contrato_obrero WHERE id_obrero = @idObrero ORDER BY fecha_vencimiento DESC, id_contrato_obrero DESC";
				cmd.Parameters.AddWithValue("@idObrero", idObrero);
				await using var reader = await cmd.ExecuteReaderAsync();
				while (await reader.ReadAsync())
				{
					contratos.Add(new
					{
						id_contrato_obrero = reader.GetInt32("id_contrato_obrero"),
						nombre_archivo = ReadNullableString(reader, "nombre_archivo"),
						fecha_vencimiento = ReadNullableDate(reader, "fecha_vencimiento")
					});
				}
			}

			PostToJs(new
			{
				type = "obreros_contratos_listar_response",
				requestId,
				success = true,
				contratos
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "obreros_contratos_listar_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Obreros contratos listar error] {ex}");
			PostToJs(new { type = "obreros_contratos_listar_response", requestId, success = false, error = "No se pudieron cargar los contratos." });
		}
	}

	private async Task HandleObrerosContratoDescargarAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAutenticado(requestId, "obreros_contrato_descargar_response"))
			return;

		try
		{
			var idContrato = ReadPositiveInt(root, "id_contrato_obrero");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			string? nombreArchivo = null;
			byte[]? archivo = null;

			await using (var cmd = conn.CreateCommand())
			{
				cmd.CommandText = "SELECT nombre_archivo, archivo FROM contrato_obrero WHERE id_contrato_obrero = @idContrato LIMIT 1";
				cmd.Parameters.AddWithValue("@idContrato", idContrato);
				await using var reader = await cmd.ExecuteReaderAsync();
				if (await reader.ReadAsync())
				{
					nombreArchivo = ReadNullableString(reader, "nombre_archivo");
					if (!reader.IsDBNull(reader.GetOrdinal("archivo")))
						archivo = (byte[])reader["archivo"];
				}
			}

			if (archivo is null)
				throw new InvalidOperationException("El contrato solicitado no existe.");

			var nombreSeguro = string.IsNullOrWhiteSpace(nombreArchivo) ? $"contrato-{idContrato}" : nombreArchivo;
			var base64 = Convert.ToBase64String(archivo);
			var ext = Path.GetExtension(nombreSeguro).ToLowerInvariant();
			var mime = ext switch
			{
				".pdf" => "application/pdf",
				".doc" => "application/msword",
				".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
				".jpg" or ".jpeg" => "image/jpeg",
				".png" => "image/png",
				_ => "application/octet-stream"
			};

			PostToJs(new
			{
				type = "obreros_contrato_descargar_response",
				requestId,
				success = true,
				nombre_archivo = nombreSeguro,
				tipo_contenido = mime,
				contenido_base64 = base64
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "obreros_contrato_descargar_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Obreros contrato descargar error] {ex}");
			PostToJs(new { type = "obreros_contrato_descargar_response", requestId, success = false, error = "No se pudo descargar el contrato." });
		}
	}

	private async Task HandleObrerosContratoEliminarAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAdministrador(requestId, "obreros_contrato_eliminar_response"))
			return;

		try
		{
			var idContrato = ReadPositiveInt(root, "id_contrato_obrero");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			await using (var cmd = conn.CreateCommand())
			{
				cmd.CommandText = "DELETE FROM contrato_obrero WHERE id_contrato_obrero = @idContrato";
				cmd.Parameters.AddWithValue("@idContrato", idContrato);
				var rows = await cmd.ExecuteNonQueryAsync();
				if (rows == 0)
					throw new InvalidOperationException("El contrato no existe.");
			}

			PostToJs(new
			{
				type = "obreros_contrato_eliminar_response",
				requestId,
				success = true,
				message = "Contrato eliminado correctamente."
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "obreros_contrato_eliminar_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Obreros contrato eliminar error] {ex}");
			PostToJs(new { type = "obreros_contrato_eliminar_response", requestId, success = false, error = "No se pudo eliminar el contrato." });
		}
	}

	private async Task HandleObrerosContratoEditarFechaAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAdministrador(requestId, "obreros_contrato_editar_fecha_response"))
			return;

		try
		{
			var idContrato = ReadPositiveInt(root, "id_contrato_obrero");
			var fechaVencimiento = root.TryGetProperty("fecha_vencimiento", out var fechaProp) && fechaProp.ValueKind == JsonValueKind.String
				? (fechaProp.GetString()?.Trim() ?? string.Empty)
				: string.Empty;

			string? fechaDb = null;
			if (!string.IsNullOrWhiteSpace(fechaVencimiento))
			{
				if (!DateTime.TryParseExact(fechaVencimiento, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _))
					throw new InvalidOperationException("Formato de fecha inválido.");
				fechaDb = fechaVencimiento;
			}

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			await using (var cmd = conn.CreateCommand())
			{
				cmd.CommandText = "UPDATE contrato_obrero SET fecha_vencimiento = @fechaVencimiento WHERE id_contrato_obrero = @idContrato";
				cmd.Parameters.AddWithValue("@fechaVencimiento", fechaDb is null ? DBNull.Value : fechaDb);
				cmd.Parameters.AddWithValue("@idContrato", idContrato);
				var rows = await cmd.ExecuteNonQueryAsync();
				if (rows == 0)
					throw new InvalidOperationException("El contrato no existe.");
			}

			PostToJs(new
			{
				type = "obreros_contrato_editar_fecha_response",
				requestId,
				success = true,
				message = "Fecha de vencimiento actualizada."
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "obreros_contrato_editar_fecha_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Obreros contrato editar fecha error] {ex}");
			PostToJs(new { type = "obreros_contrato_editar_fecha_response", requestId, success = false, error = "No se pudo actualizar la fecha del contrato." });
		}
	}

	private async Task HandleMaquinariaCertificadosListarAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAutenticado(requestId, "maquinaria_certificados_listar_response"))
			return;

		try
		{
			var idMaquinaria = ReadPositiveInt(root, "id_maquinaria");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			var certificados = new List<object>();
			await using (var cmd = conn.CreateCommand())
			{
				cmd.CommandText = "SELECT id_certificado, nombre_archivo, fecha_vencimiento FROM certificado WHERE id_maquinaria = @idMaquinaria ORDER BY fecha_vencimiento ASC";
				cmd.Parameters.AddWithValue("@idMaquinaria", idMaquinaria);
				await using var reader = await cmd.ExecuteReaderAsync();
				while (await reader.ReadAsync())
				{
					certificados.Add(new
					{
						id_certificado = reader.GetInt32("id_certificado"),
						nombre_archivo = ReadNullableString(reader, "nombre_archivo"),
						fecha_vencimiento = ReadNullableDate(reader, "fecha_vencimiento")
					});
				}
			}

			PostToJs(new
			{
				type = "maquinaria_certificados_listar_response",
				requestId,
				success = true,
				certificados
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "maquinaria_certificados_listar_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Maquinaria certificados listar error] {ex}");
			PostToJs(new { type = "maquinaria_certificados_listar_response", requestId, success = false, error = "No se pudieron cargar los certificados." });
		}
	}

	private async Task HandleMaquinariaCertificadoSubirAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAdministrador(requestId, "maquinaria_certificado_subir_response"))
			return;

		try
		{
			var idMaquinaria = ReadPositiveInt(root, "id_maquinaria");
			var fechaVencimiento = root.TryGetProperty("fecha_vencimiento", out var fechaProp) && fechaProp.ValueKind == JsonValueKind.String
				? (fechaProp.GetString()?.Trim() ?? string.Empty)
				: string.Empty;
			var nombreArchivo = ReadRequiredString(root, "nombre_archivo");
			var contenidoBase64 = ReadRequiredString(root, "contenido_base64");

			string? fechaDb = null;
			if (!string.IsNullOrWhiteSpace(fechaVencimiento))
			{
				if (!DateTime.TryParseExact(fechaVencimiento, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out _))
					throw new InvalidOperationException("Formato de fecha inválido.");
				fechaDb = fechaVencimiento;
			}

			byte[] archivo;
			try
			{
				archivo = Convert.FromBase64String(contenidoBase64);
			}
			catch (FormatException)
			{
				throw new InvalidOperationException("El archivo seleccionado es inválido.");
			}

			if (archivo.Length > 10 * 1024 * 1024)
				throw new InvalidOperationException("El certificado no puede superar los 10 MB.");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			await using var cmd = conn.CreateCommand();
			cmd.CommandText =
				"INSERT INTO certificado (archivo, nombre_archivo, id_maquinaria, fecha_vencimiento) VALUES (@archivo, @nombreArchivo, @idMaquinaria, @fechaVencimiento)";
			cmd.Parameters.Add("@archivo", MySqlDbType.LongBlob).Value = archivo;
			cmd.Parameters.AddWithValue("@nombreArchivo", nombreArchivo);
			cmd.Parameters.AddWithValue("@idMaquinaria", idMaquinaria);
			cmd.Parameters.AddWithValue("@fechaVencimiento", fechaDb is null ? DBNull.Value : fechaDb);
			await cmd.ExecuteNonQueryAsync();

			PostToJs(new
			{
				type = "maquinaria_certificado_subir_response",
				requestId,
				success = true,
				message = "Certificado subido correctamente."
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "maquinaria_certificado_subir_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Maquinaria certificado subir error] {ex}");
			PostToJs(new { type = "maquinaria_certificado_subir_response", requestId, success = false, error = "No se pudo subir el certificado." });
		}
	}

	private async Task HandleMaquinariaCertificadoDescargarAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAutenticado(requestId, "maquinaria_certificado_descargar_response"))
			return;

		try
		{
			var idCertificado = ReadPositiveInt(root, "id_certificado");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			await using var cmd = conn.CreateCommand();
			cmd.CommandText =
				"SELECT nombre_archivo, archivo FROM certificado WHERE id_certificado = @idCertificado LIMIT 1";
			cmd.Parameters.AddWithValue("@idCertificado", idCertificado);

			await using var reader = await cmd.ExecuteReaderAsync(System.Data.CommandBehavior.SequentialAccess);
			if (!await reader.ReadAsync())
				throw new InvalidOperationException("El certificado indicado no existe.");

			var nombreArchivo = ReadNullableString(reader, "nombre_archivo") ?? $"certificado-{idCertificado}";
			var archivoOrdinal = reader.GetOrdinal("archivo");
			var archivo = (byte[])reader.GetValue(archivoOrdinal);

			PostToJs(new
			{
				type = "maquinaria_certificado_descargar_response",
				requestId,
				success = true,
				nombre_archivo = nombreArchivo,
				tipo_contenido = GuessMimeType(nombreArchivo),
				contenido_base64 = Convert.ToBase64String(archivo)
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "maquinaria_certificado_descargar_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Maquinaria certificado descargar error] {ex}");
			PostToJs(new { type = "maquinaria_certificado_descargar_response", requestId, success = false, error = "No se pudo descargar el certificado." });
		}
	}

	private async Task HandleMaquinariaCertificadoEliminarAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAdministrador(requestId, "maquinaria_certificado_eliminar_response"))
			return;

		try
		{
			var idCertificado = ReadPositiveInt(root, "id_certificado");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			await using var cmd = conn.CreateCommand();
			cmd.CommandText = "DELETE FROM certificado WHERE id_certificado = @idCertificado";
			cmd.Parameters.AddWithValue("@idCertificado", idCertificado);
			var affected = await cmd.ExecuteNonQueryAsync();

			if (affected == 0)
				throw new InvalidOperationException("El certificado indicado no existe.");

			PostToJs(new
			{
				type = "maquinaria_certificado_eliminar_response",
				requestId,
				success = true,
				message = "Certificado eliminado correctamente."
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "maquinaria_certificado_eliminar_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Maquinaria certificado eliminar error] {ex}");
			PostToJs(new { type = "maquinaria_certificado_eliminar_response", requestId, success = false, error = "No se pudo eliminar el certificado." });
		}
	}

	private async Task HandleMaquinariaCertificadoEditarFechaAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAdministrador(requestId, "maquinaria_certificado_editar_fecha_response"))
			return;

		try
		{
			var idCertificado = ReadPositiveInt(root, "id_certificado");
			string? fechaVencimiento = null;
			if (root.TryGetProperty("fecha_vencimiento", out var fechaProp) && fechaProp.ValueKind == JsonValueKind.String)
			{
				var val = fechaProp.GetString()?.Trim();
				if (!string.IsNullOrEmpty(val))
				{
					fechaVencimiento = val.Length > 10 ? val.Substring(0, 10) : val;
				}
			}

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();
			await using var cmd = conn.CreateCommand();
			cmd.CommandText = "UPDATE certificado SET fecha_vencimiento = @fechaVencimiento WHERE id_certificado = @idCertificado";
			cmd.Parameters.AddWithValue("@idCertificado", idCertificado);
			cmd.Parameters.AddWithValue("@fechaVencimiento", (object?)fechaVencimiento ?? DBNull.Value);

			var affected = await cmd.ExecuteNonQueryAsync();
			if (affected == 0)
			{
				throw new InvalidOperationException("El certificado indicado no existe.");
			}

			PostToJs(new
			{
				type = "maquinaria_certificado_editar_fecha_response",
				requestId,
				success = true,
				message = "Fecha de vencimiento actualizada correctamente."
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "maquinaria_certificado_editar_fecha_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Maquinaria certificado editar fecha error] {ex}");
			PostToJs(new { type = "maquinaria_certificado_editar_fecha_response", requestId, success = false, error = "No se pudo actualizar la fecha del certificado." });
		}
	}

	private async Task HandleMaquinariaListarAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAutenticado(requestId, "maquinaria_listar_response"))
			return;

		try
		{
			var page = 1;
			if (root.TryGetProperty("page", out var pageProp))
			{
				if (pageProp.ValueKind == JsonValueKind.Number && pageProp.TryGetInt32(out var pageNumber) && pageNumber > 0)
					page = pageNumber;
				else if (pageProp.ValueKind == JsonValueKind.String && int.TryParse(pageProp.GetString(), out pageNumber) && pageNumber > 0)
					page = pageNumber;
			}

			var limit = 10;
			if (root.TryGetProperty("limit", out var limitProp))
			{
				if (limitProp.ValueKind == JsonValueKind.Number && limitProp.TryGetInt32(out var limitNumber) && limitNumber > 0)
					limit = limitNumber;
				else if (limitProp.ValueKind == JsonValueKind.String && int.TryParse(limitProp.GetString(), out limitNumber) && limitNumber > 0)
					limit = limitNumber;
			}
			limit = Math.Clamp(limit, 1, 100);

			var search = root.TryGetProperty("search", out var searchProp) && searchProp.ValueKind == JsonValueKind.String
				? (searchProp.GetString()?.Trim() ?? string.Empty)
				: string.Empty;

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			var where = new List<string>();
			var countParams = new List<MySqlParameter>();

			if (!string.IsNullOrWhiteSpace(search))
			{
				where.Add("(nombre LIKE @search OR marca LIKE @search)");
				countParams.Add(new MySqlParameter("@search", $"%{search}%"));
			}

			var whereSql = where.Count > 0 ? " WHERE " + string.Join(" AND ", where) : string.Empty;

			var total = 0;
			await using (var countCmd = conn.CreateCommand())
			{
				countCmd.CommandText = "SELECT COUNT(*) FROM maquinaria" + whereSql;
				foreach (var param in countParams)
					countCmd.Parameters.AddWithValue(param.ParameterName, param.Value);
				total = Convert.ToInt32(await countCmd.ExecuteScalarAsync());
			}

			var totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)limit));
			page = Math.Min(page, totalPages);
			var offset = (page - 1) * limit;

			await using var cmd = conn.CreateCommand();
			cmd.CommandText =
				"SELECT id_maquinaria, nombre, marca,"
				+ " (SELECT MIN(fecha_vencimiento) FROM certificado WHERE certificado.id_maquinaria = maquinaria.id_maquinaria) AS cert_vencimiento"
				+ " FROM maquinaria"
				+ whereSql
				+ " ORDER BY id_maquinaria DESC LIMIT @limit OFFSET @offset";

			foreach (var param in countParams)
				cmd.Parameters.AddWithValue(param.ParameterName, param.Value);
			cmd.Parameters.AddWithValue("@limit", limit);
			cmd.Parameters.AddWithValue("@offset", offset);

			var items = new List<object>();
			await using var reader = await cmd.ExecuteReaderAsync();
			while (await reader.ReadAsync())
			{
				var vencOrdinal = reader.GetOrdinal("cert_vencimiento");
				items.Add(new
				{
					id_maquinaria = reader.GetInt32("id_maquinaria"),
					nombre = reader.GetString("nombre"),
					marca = ReadNullableString(reader, "marca"),
					cert_vencimiento = reader.IsDBNull(vencOrdinal) ? null : ReadNullableString(reader, "cert_vencimiento")
				});
			}

			PostToJs(new
			{
				type = "maquinaria_listar_response",
				requestId,
				success = true,
				maquinaria = items,
				total,
				page,
				per_page = limit,
				total_pages = totalPages
			});
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Maquinaria listar error] {ex}");
			PostToJs(new { type = "maquinaria_listar_response", requestId, success = false, error = "No se pudo cargar la maquinaria." });
		}
	}

	private async Task HandleGuardarMaquinariaAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAdministrador(requestId, "maquinaria_guardar_response"))
			return;

		try
		{
			var nombre = ReadRequiredString(root, "nombre");
			var marca = root.TryGetProperty("marca", out var marcaProp) && marcaProp.ValueKind == JsonValueKind.String
				? (marcaProp.GetString()?.Trim() ?? string.Empty)
				: string.Empty;
			var idMaquinaria = TryReadPositiveInt(root, "id_maquinaria");

			if (nombre.Length > 150)
				throw new InvalidOperationException("El nombre es demasiado largo.");
			if (marca.Length > 100)
				throw new InvalidOperationException("La marca es demasiado larga.");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			if (idMaquinaria.HasValue)
			{
				await using (var existsCmd = conn.CreateCommand())
				{
					existsCmd.CommandText = "SELECT id_maquinaria FROM maquinaria WHERE id_maquinaria = @id LIMIT 1";
					existsCmd.Parameters.AddWithValue("@id", idMaquinaria.Value);
					var exists = await existsCmd.ExecuteScalarAsync();
					if (exists is null)
						throw new InvalidOperationException("La maquinaria indicada no existe.");
				}

				await using var updateCmd = conn.CreateCommand();
				updateCmd.CommandText =
					"UPDATE maquinaria SET nombre = @nombre, marca = @marca WHERE id_maquinaria = @id";
				updateCmd.Parameters.AddWithValue("@nombre", nombre);
				updateCmd.Parameters.AddWithValue("@marca", string.IsNullOrWhiteSpace(marca) ? DBNull.Value : marca);
				updateCmd.Parameters.AddWithValue("@id", idMaquinaria.Value);
				await updateCmd.ExecuteNonQueryAsync();

				PostToJs(new
				{
					type = "maquinaria_guardar_response",
					requestId,
					success = true,
					message = "Maquinaria actualizada correctamente."
				});
				return;
			}

			await using var insertCmd = conn.CreateCommand();
			insertCmd.CommandText =
				"INSERT INTO maquinaria (nombre, marca) VALUES (@nombre, @marca)";
			insertCmd.Parameters.AddWithValue("@nombre", nombre);
			insertCmd.Parameters.AddWithValue("@marca", string.IsNullOrWhiteSpace(marca) ? DBNull.Value : marca);
			await insertCmd.ExecuteNonQueryAsync();

			PostToJs(new
			{
				type = "maquinaria_guardar_response",
				requestId,
				success = true,
				message = "Maquinaria registrada correctamente."
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "maquinaria_guardar_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Maquinaria guardar error] {ex}");
			PostToJs(new { type = "maquinaria_guardar_response", requestId, success = false, error = "No se pudo guardar la maquinaria." });
		}
	}

	private async Task HandleEliminarMaquinariaAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureAdministrador(requestId, "maquinaria_eliminar_response"))
			return;

		try
		{
			var idMaquinaria = ReadPositiveInt(root, "id_maquinaria");

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			await using var cmd = conn.CreateCommand();
			cmd.CommandText = "DELETE FROM maquinaria WHERE id_maquinaria = @id";
			cmd.Parameters.AddWithValue("@id", idMaquinaria);
			var affected = await cmd.ExecuteNonQueryAsync();

			if (affected == 0)
				throw new InvalidOperationException("La maquinaria indicada no existe.");

			PostToJs(new
			{
				type = "maquinaria_eliminar_response",
				requestId,
				success = true,
				message = "Maquinaria eliminada correctamente."
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "maquinaria_eliminar_response", requestId, success = false, error = ex.Message });
		}
		catch (MySqlException ex) when (ex.Number == 1451)
		{
			PostToJs(new { type = "maquinaria_eliminar_response", requestId, success = false, error = "No se puede eliminar porque está asignada a una obra." });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Maquinaria eliminar error] {ex}");
			PostToJs(new { type = "maquinaria_eliminar_response", requestId, success = false, error = "No se pudo eliminar la maquinaria." });
		}
	}

	private async Task HandleGuardarAsistenciaAsync(JsonElement root)
	{
		var requestId = root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;

		if (!EnsureCapatazOAdmin(requestId, "asistencia_guardar_response"))
			return;

		try
		{
			var idObra = ReadPositiveInt(root, "id_obra");
			var fecha = ReadRequiredString(root, "fecha");
			var finalizaObra = root.TryGetProperty("finaliza_obra", out var finalizaProp) && finalizaProp.ValueKind == JsonValueKind.True;
			var idUsuario = _currentUserId ?? ReadPositiveInt(root, "id_usuario");

			if (!root.TryGetProperty("obreros", out var obrerosElement) || obrerosElement.ValueKind != JsonValueKind.Array || obrerosElement.GetArrayLength() == 0)
				throw new InvalidOperationException("Seleccioná al menos un obrero.");

			var obreros = new List<(int IdObrero, string HoraEntrada, string HoraSalida)>();
			foreach (var item in obrerosElement.EnumerateArray())
			{
				var idObrero = ReadPositiveInt(item, "id_obrero");
				var horaEntrada = ReadRequiredString(item, "hora_entrada");
				var horaSalida = ReadRequiredString(item, "hora_salida");

				if (TimeSpan.Parse(horaSalida) <= TimeSpan.Parse(horaEntrada))
					throw new InvalidOperationException("La hora de salida debe ser mayor a la de entrada.");

				obreros.Add((idObrero, horaEntrada, horaSalida));
			}

			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();
			await using var tx = await conn.BeginTransactionAsync();

			var registrosInsertados = 0;
			foreach (var obrero in obreros)
			{
				await using var insertRegistro = conn.CreateCommand();
				insertRegistro.Transaction = tx;
				insertRegistro.CommandText =
					"INSERT INTO registros (fecha, hora_entrada, hora_salida, horas_trabajadas, id_obrero, id_obra, id_usuario) " +
					"VALUES (@fecha, @entrada, @salida, @horas, @idObrero, @idObra, @idUsuario)";
				insertRegistro.Parameters.AddWithValue("@fecha", fecha);
				insertRegistro.Parameters.AddWithValue("@entrada", obrero.HoraEntrada);
				insertRegistro.Parameters.AddWithValue("@salida", obrero.HoraSalida);
				insertRegistro.Parameters.AddWithValue("@horas", decimal.Parse(CalcularHorasTrabajadas(obrero.HoraEntrada, obrero.HoraSalida)));
				insertRegistro.Parameters.AddWithValue("@idObrero", obrero.IdObrero);
				insertRegistro.Parameters.AddWithValue("@idObra", idObra);
				insertRegistro.Parameters.AddWithValue("@idUsuario", idUsuario);
				await insertRegistro.ExecuteNonQueryAsync();
				registrosInsertados++;
			}

			var recursosInsertados = 0;
			recursosInsertados += await InsertarRecursosAsync(conn, tx, root, "materiales", idObra, fecha, true);
			recursosInsertados += await InsertarRecursosAsync(conn, tx, root, "herramientas", idObra, fecha, false);

			var maquinariaInsertada = 0;
			if (root.TryGetProperty("maquinaria", out var maquinariaElement) && maquinariaElement.ValueKind == JsonValueKind.Array)
			{
				foreach (var item in maquinariaElement.EnumerateArray())
				{
					var idMaquinaria = ReadPositiveInt(item, "id_maquinaria");
					await using var cmd = conn.CreateCommand();
					cmd.Transaction = tx;
					cmd.CommandText = "INSERT IGNORE INTO asistencia_maquinaria (id_obra, id_maquinaria, fecha) VALUES (@idObra, @idMaquinaria, @fecha)";
					cmd.Parameters.AddWithValue("@idObra", idObra);
					cmd.Parameters.AddWithValue("@idMaquinaria", idMaquinaria);
					cmd.Parameters.AddWithValue("@fecha", fecha);
					await cmd.ExecuteNonQueryAsync();
					maquinariaInsertada++;
				}
			}

			if (finalizaObra)
			{
				await using var updateObra = conn.CreateCommand();
				updateObra.Transaction = tx;
				updateObra.CommandText = "UPDATE obras SET fecha_fin = @fecha WHERE id_obra = @idObra";
				updateObra.Parameters.AddWithValue("@fecha", fecha);
				updateObra.Parameters.AddWithValue("@idObra", idObra);
				await updateObra.ExecuteNonQueryAsync();
			}

			await tx.CommitAsync();

			PostToJs(new
			{
				type = "asistencia_guardar_response",
				requestId,
				success = true,
				registros_insertados = registrosInsertados,
				recursos_insertados = recursosInsertados,
				maquinaria_insertada = maquinariaInsertada
			});
		}
		catch (InvalidOperationException ex)
		{
			PostToJs(new { type = "asistencia_guardar_response", requestId, success = false, error = ex.Message });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Asistencia guardar error] {ex}");
			PostToJs(new { type = "asistencia_guardar_response", requestId, success = false, error = "No se pudo guardar la asistencia." });
		}
	}

	private static int ReadPositiveInt(JsonElement root, string propertyName)
	{
		if (!root.TryGetProperty(propertyName, out var prop))
			throw new InvalidOperationException($"Falta el campo {propertyName}.");

		if (prop.ValueKind == JsonValueKind.Number && prop.TryGetInt32(out var number) && number > 0)
			return number;

		if (prop.ValueKind == JsonValueKind.String && int.TryParse(prop.GetString(), out number) && number > 0)
			return number;

		throw new InvalidOperationException($"El campo {propertyName} es inválido.");
	}

	private static string ReadRequestId(JsonElement root)
	{
		return root.TryGetProperty("requestId", out var requestIdProp)
			? requestIdProp.GetString() ?? string.Empty
			: string.Empty;
	}

	private bool EnsureAdministrador(string requestId, string responseType)
	{
		if (_currentUserId is null)
		{
			PostToJs(new { type = responseType, requestId, success = false, error = "Sesión no válida. Iniciá sesión nuevamente." });
			return false;
		}

		if (!string.Equals(_currentRol, "Administrador", StringComparison.Ordinal))
		{
			PostToJs(new { type = responseType, requestId, success = false, error = "No tenés permisos para gestionar usuarios." });
			return false;
		}

		return true;
	}

	private bool EnsureAutenticado(string requestId, string responseType)
	{
		if (_currentUserId is null)
		{
			PostToJs(new { type = responseType, requestId, success = false, error = "Sesión no válida. Iniciá sesión nuevamente." });
			return false;
		}
		return true;
	}

	private bool EnsureCapatazOAdmin(string requestId, string responseType)
	{
		if (_currentUserId is null)
		{
			PostToJs(new { type = responseType, requestId, success = false, error = "Sesión no válida. Iniciá sesión nuevamente." });
			return false;
		}

		if (!string.Equals(_currentRol, "Administrador", StringComparison.Ordinal) &&
		    !string.Equals(_currentRol, "Capataz", StringComparison.Ordinal))
		{
			PostToJs(new { type = responseType, requestId, success = false, error = "No tenés permisos para esta acción." });
			return false;
		}

		return true;
	}

	private static int? TryReadPositiveInt(JsonElement root, string propertyName)
	{
		if (!root.TryGetProperty(propertyName, out var prop))
			return null;

		if (prop.ValueKind == JsonValueKind.Null)
			return null;

		if (prop.ValueKind == JsonValueKind.Number && prop.TryGetInt32(out var number) && number > 0)
			return number;

		if (prop.ValueKind == JsonValueKind.String)
		{
			var text = prop.GetString()?.Trim();
			if (string.IsNullOrWhiteSpace(text))
				return null;

			if (int.TryParse(text, out number) && number > 0)
				return number;
		}

		throw new InvalidOperationException($"El campo {propertyName} es inválido.");
	}

	private static string ReadRequiredString(JsonElement root, string propertyName)
	{
		if (!root.TryGetProperty(propertyName, out var prop) || prop.ValueKind != JsonValueKind.String)
			throw new InvalidOperationException($"Falta el campo {propertyName}.");

		var value = prop.GetString()?.Trim() ?? string.Empty;
		if (string.IsNullOrWhiteSpace(value))
			throw new InvalidOperationException($"El campo {propertyName} es obligatorio.");

		return value;
	}

	private static string ReadPasswordString(JsonElement root, string propertyName, bool required)
	{
		if (!root.TryGetProperty(propertyName, out var prop) || prop.ValueKind != JsonValueKind.String)
		{
			if (required)
				throw new InvalidOperationException($"Falta el campo {propertyName}.");

			return string.Empty;
		}

		var value = prop.GetString() ?? string.Empty;
		if (required && value.Length == 0)
			throw new InvalidOperationException($"El campo {propertyName} es obligatorio.");

		return value;
	}

	private static void ValidateUserFields(string nombre, string usuario, string password, string rol, bool validatePassword)
	{
		if (nombre.Length == 0)
			throw new InvalidOperationException("El nombre completo es obligatorio.");

		if (nombre.Length > 100)
			throw new InvalidOperationException("El nombre completo es demasiado largo.");

		if (usuario.Length == 0)
			throw new InvalidOperationException("El nombre de usuario es obligatorio.");

		if (usuario.Length > 50)
			throw new InvalidOperationException("El nombre de usuario es demasiado largo.");

		if (validatePassword)
		{
			if (password.Length < 6)
				throw new InvalidOperationException("La contraseña debe tener al menos 6 caracteres.");

			if (password.Length > 255)
				throw new InvalidOperationException("La contraseña es demasiado larga.");
		}

		if (!string.Equals(rol, "Administrador", StringComparison.Ordinal) &&
		    !string.Equals(rol, "Capataz", StringComparison.Ordinal))
		{
			throw new InvalidOperationException("Seleccione un rol válido.");
		}
	}

	private static Dictionary<string, object?> ValidateObraPayload(JsonElement root)
	{
		var numeroContrata = SanitizeText(root, "numero_contrata", 50, true);
		var nombre = SanitizeText(root, "nombre", 150, true);
		var direccion = SanitizeText(root, "direccion", 200, false);
		var descripcion = SanitizeText(root, "descripcion", 65535, false);
		var fechaInicio = NormalizeDate(root, "fecha_inicio");
		var fechaFin = NormalizeDate(root, "fecha_fin");
		var nombreCliente = SanitizeText(root, "nombre_cliente", 150, true);
		var telefonoCliente = SanitizeText(root, "telefono_cliente", 30, false);

		if (fechaInicio is not null && fechaFin is not null && string.CompareOrdinal(fechaFin, fechaInicio) < 0)
			throw new InvalidOperationException("La fecha de fin no puede ser menor a la de inicio.");

		return new Dictionary<string, object?>
		{
			["numero_contrata"] = numeroContrata,
			["nombre"] = nombre,
			["direccion"] = direccion,
			["descripcion"] = descripcion,
			["fecha_inicio"] = fechaInicio,
			["fecha_fin"] = fechaFin,
			["nombre_cliente"] = nombreCliente,
			["telefono_cliente"] = telefonoCliente
		};
	}

	private static (string NombreArchivo, byte[] Archivo)? ReadContrato(JsonElement root)
	{
		if (!root.TryGetProperty("contrato", out var contratoProp) || contratoProp.ValueKind != JsonValueKind.Object)
			return null;

		var nombreArchivo = SanitizeText(contratoProp, "nombre_archivo", 255, true);
		var contenidoBase64 = ReadRequiredString(contratoProp, "contenido_base64");

		byte[] archivo;
		try
		{
			archivo = Convert.FromBase64String(contenidoBase64);
		}
		catch (FormatException)
		{
			throw new InvalidOperationException("El contrato seleccionado es inválido.");
		}

		if (archivo.Length > 10 * 1024 * 1024)
			throw new InvalidOperationException("El contrato no puede superar los 10 MB.");

		return (nombreArchivo, archivo);
	}

	private static string SanitizeText(JsonElement root, string propertyName, int maxLength, bool required)
	{
		var value = root.TryGetProperty(propertyName, out var prop) && prop.ValueKind == JsonValueKind.String
			? prop.GetString()?.Trim() ?? string.Empty
			: string.Empty;

		if (value.Length == 0)
		{
			if (required)
				throw new InvalidOperationException("Número de contrata, nombre de la obra y cliente son obligatorios.");

			return string.Empty;
		}

		if (value.Length > maxLength)
			throw new InvalidOperationException("Uno de los campos supera la longitud permitida.");

		return value;
	}

	private static string? NormalizeDate(JsonElement root, string propertyName)
	{
		if (!root.TryGetProperty(propertyName, out var prop) || prop.ValueKind != JsonValueKind.String)
			return null;

		var value = prop.GetString()?.Trim() ?? string.Empty;
		if (value.Length == 0)
			return null;

		if (!DateTime.TryParseExact(value, "yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture, System.Globalization.DateTimeStyles.None, out var date))
			throw new InvalidOperationException("Formato de fecha inválido.");

		return date.ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
	}

	private static string CalcularHorasTrabajadas(string horaEntrada, string horaSalida)
	{
		var entrada = TimeSpan.Parse(horaEntrada);
		var salida = TimeSpan.Parse(horaSalida);
		if (salida <= entrada)
			throw new InvalidOperationException("La hora de salida debe ser mayor a la de entrada.");

		return ((decimal)(salida - entrada).TotalHours).ToString("0.00", System.Globalization.CultureInfo.InvariantCulture);
	}

	private static void AddObraParameters(MySqlCommand cmd, Dictionary<string, object?> payload, int? idObra)
	{
		cmd.Parameters.AddWithValue("@numeroContrata", payload["numero_contrata"]);
		cmd.Parameters.AddWithValue("@nombre", payload["nombre"]);
		cmd.Parameters.AddWithValue("@direccion", ToDbValue(payload["direccion"]));
		cmd.Parameters.AddWithValue("@descripcion", ToDbValue(payload["descripcion"]));
		cmd.Parameters.AddWithValue("@fechaInicio", ToDbValue(payload["fecha_inicio"]));
		cmd.Parameters.AddWithValue("@fechaFin", ToDbValue(payload["fecha_fin"]));
		cmd.Parameters.AddWithValue("@nombreCliente", payload["nombre_cliente"]);
		cmd.Parameters.AddWithValue("@telefonoCliente", ToDbValue(payload["telefono_cliente"]));

		if (idObra.HasValue)
			cmd.Parameters.AddWithValue("@idObra", idObra.Value);
	}

	private static object ToDbValue(object? value)
	{
		if (value is null)
			return DBNull.Value;

		if (value is string text && string.IsNullOrWhiteSpace(text))
			return DBNull.Value;

		return value;
	}

	private static object MapObra(MySqlDataReader reader)
	{
		return new
		{
			id_obra = reader.GetInt32("id_obra"),
			numero_contrata = reader.GetString("numero_contrata"),
			nombre = reader.GetString("nombre"),
			direccion = ReadNullableString(reader, "direccion"),
			descripcion = ReadNullableString(reader, "descripcion"),
			fecha_inicio = ReadNullableDate(reader, "fecha_inicio"),
			fecha_fin = ReadNullableDate(reader, "fecha_fin"),
			nombre_cliente = reader.GetString("nombre_cliente"),
			telefono_cliente = ReadNullableString(reader, "telefono_cliente"),
			activo = Convert.ToInt32(reader["activo"]),
			contrato_nombre_archivo = ReadNullableString(reader, "contrato_nombre_archivo")
		};
	}

	private static string? ReadNullableString(MySqlDataReader reader, string columnName)
	{
		var ordinal = reader.GetOrdinal(columnName);
		return reader.IsDBNull(ordinal) ? null : reader.GetString(ordinal);
	}

	private static string? ReadNullableDate(MySqlDataReader reader, string columnName)
	{
		var ordinal = reader.GetOrdinal(columnName);
		if (reader.IsDBNull(ordinal))
			return null;

		return reader.GetDateTime(ordinal).ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture);
	}

	private static async Task<bool> ObraExistsAsync(MySqlConnection conn, int idObra)
	{
		await using var cmd = conn.CreateCommand();
		cmd.CommandText = "SELECT 1 FROM obras WHERE id_obra = @idObra LIMIT 1";
		cmd.Parameters.AddWithValue("@idObra", idObra);
		var result = await cmd.ExecuteScalarAsync();
		return result is not null;
	}

	private static async Task<object> GetObraByIdAsync(MySqlConnection conn, int idObra)
	{
		await using var cmd = conn.CreateCommand();
		cmd.CommandText =
			"SELECT o.id_obra, o.numero_contrata, o.nombre, o.direccion, o.descripcion, o.fecha_inicio, o.fecha_fin, o.nombre_cliente, o.telefono_cliente, o.activo, " +
			"c.nombre_archivo AS contrato_nombre_archivo " +
			"FROM obras o " +
			"LEFT JOIN (" +
			"SELECT c1.id_obra, c1.nombre_archivo FROM contratos c1 " +
			"INNER JOIN (SELECT id_obra, MAX(id_contrato) AS max_id_contrato FROM contratos GROUP BY id_obra) ult " +
			"ON ult.id_obra = c1.id_obra AND ult.max_id_contrato = c1.id_contrato" +
			") c ON c.id_obra = o.id_obra " +
			"WHERE o.id_obra = @idObra LIMIT 1";
		cmd.Parameters.AddWithValue("@idObra", idObra);

		await using var reader = await cmd.ExecuteReaderAsync();
		if (!await reader.ReadAsync())
			throw new InvalidOperationException("La obra indicada no existe.");

		return MapObra(reader);
	}

	private static async Task GuardarContratoAsync(MySqlConnection conn, MySqlTransaction tx, int idObra, string nombreArchivo, byte[] archivo)
	{
		await using (var deleteCmd = conn.CreateCommand())
		{
			deleteCmd.Transaction = tx;
			deleteCmd.CommandText = "DELETE FROM contratos WHERE id_obra = @idObra";
			deleteCmd.Parameters.AddWithValue("@idObra", idObra);
			await deleteCmd.ExecuteNonQueryAsync();
		}

		await using var insertCmd = conn.CreateCommand();
		insertCmd.Transaction = tx;
		insertCmd.CommandText =
			"INSERT INTO contratos (id_obra, archivo, nombre_archivo, fecha_subida) VALUES (@idObra, @archivo, @nombreArchivo, CURDATE())";
		insertCmd.Parameters.AddWithValue("@idObra", idObra);
		insertCmd.Parameters.Add("@archivo", MySqlDbType.LongBlob).Value = archivo;
		insertCmd.Parameters.AddWithValue("@nombreArchivo", nombreArchivo);
		await insertCmd.ExecuteNonQueryAsync();
	}

	private static string GuessMimeType(string nombreArchivo)
	{
		var extension = Path.GetExtension(nombreArchivo)?.ToLowerInvariant();
		return extension switch
		{
			".pdf" => "application/pdf",
			".doc" => "application/msword",
			".docx" => "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
			_ => "application/octet-stream"
		};
	}

	private static async Task<List<string>> LeerRecursosAsync(MySqlConnection conn, bool esMaterial)
	{
		var items = new List<string>();
		await using var cmd = conn.CreateCommand();
		cmd.CommandText = "SELECT DISTINCT nombre FROM recursos WHERE es_material = @esMaterial ORDER BY nombre ASC";
		cmd.Parameters.AddWithValue("@esMaterial", esMaterial);
		await using var reader = await cmd.ExecuteReaderAsync();
		while (await reader.ReadAsync())
		{
			items.Add(reader.GetString("nombre"));
		}
		return items;
	}

	private static async Task<int> InsertarRecursosAsync(MySqlConnection conn, MySqlTransaction tx, JsonElement root, string propertyName, int idObra, string fecha, bool esMaterial)
	{
		if (!root.TryGetProperty(propertyName, out var recursosElement) || recursosElement.ValueKind != JsonValueKind.Array)
			return 0;

		var count = 0;
		foreach (var item in recursosElement.EnumerateArray())
		{
			var nombre = ReadRequiredString(item, "nombre");
			var cantidad = ReadPositiveDecimal(item, "cantidad");
			var precio = esMaterial ? ReadNonNegativeDecimal(item, "precio_unitario") : (decimal?)null;

			await using var cmd = conn.CreateCommand();
			cmd.Transaction = tx;
			cmd.CommandText =
				"INSERT INTO recursos (id_obra, id_registro, fecha, nombre, cantidad, precio_unitario, es_material) " +
				"VALUES (@idObra, NULL, @fecha, @nombre, @cantidad, @precio, @esMaterial)";
			cmd.Parameters.AddWithValue("@idObra", idObra);
			cmd.Parameters.AddWithValue("@fecha", fecha);
			cmd.Parameters.AddWithValue("@nombre", nombre);
			cmd.Parameters.AddWithValue("@cantidad", cantidad);
			cmd.Parameters.AddWithValue("@precio", precio.HasValue ? precio.Value : DBNull.Value);
			cmd.Parameters.AddWithValue("@esMaterial", esMaterial);
			await cmd.ExecuteNonQueryAsync();
			count++;
		}

		return count;
	}

	private static decimal ReadPositiveDecimal(JsonElement root, string propertyName)
	{
		var value = ReadDecimal(root, propertyName);
		if (value <= 0)
			throw new InvalidOperationException($"El campo {propertyName} debe ser mayor a cero.");
		return value;
	}

	private static decimal ReadNonNegativeDecimal(JsonElement root, string propertyName)
	{
		var value = ReadDecimal(root, propertyName);
		if (value < 0)
			throw new InvalidOperationException($"El campo {propertyName} no puede ser negativo.");
		return value;
	}

	private static decimal ReadDecimal(JsonElement root, string propertyName)
	{
		if (!root.TryGetProperty(propertyName, out var prop))
			throw new InvalidOperationException($"Falta el campo {propertyName}.");

		if (prop.ValueKind == JsonValueKind.Number && prop.TryGetDecimal(out var number))
			return number;

		if (prop.ValueKind == JsonValueKind.String && decimal.TryParse(prop.GetString(), System.Globalization.NumberStyles.Number, System.Globalization.CultureInfo.InvariantCulture, out number))
			return number;

		throw new InvalidOperationException($"El campo {propertyName} es inválido.");
	}

	private void PostToJs(object payload)
	{
		var json = JsonSerializer.Serialize(payload);
		// Debe ejecutarse en el hilo de UI
		Invoke(() => _webView.CoreWebView2.PostWebMessageAsString(json));
	}

	private string BuildConnectionString()
	{
		var host = _env.GetValueOrDefault("DB_HOST", "localhost");
		var port = _env.GetValueOrDefault("DB_PORT", "3306");
		var name = _env.GetValueOrDefault("DB_NAME", "portico");
		var user = _env.GetValueOrDefault("DB_USER", "");
		var pass = _env.GetValueOrDefault("DB_PASSWORD", "");

		return $"Server={host};Port={port};Database={name};User ID={user};Password={pass};CharSet=utf8mb4;";
	}

	private static Dictionary<string, string> LoadEnv()
	{
		var result  = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
		var envPath = FindEnvFile();

		if (envPath is null) return result;

		foreach (var line in File.ReadAllLines(envPath))
		{
			var trimmed = line.Trim();
			if (trimmed.Length == 0 || trimmed.StartsWith('#')) continue;

			var pos = trimmed.IndexOf('=');
			if (pos < 1) continue;

			var key   = trimmed[..pos].Trim();
			var value = trimmed[(pos + 1)..].Trim();

			// Quitar comentarios inline: key=value # comentario
			var commentIdx = value.IndexOf(" #", StringComparison.Ordinal);
			if (commentIdx >= 0) value = value[..commentIdx].Trim();

			result[key] = value;
		}

		return result;
	}

	// Busca .env subiendo directorios desde el ejecutable
	private static string? FindEnvFile()
	{
		var dir = new DirectoryInfo(AppContext.BaseDirectory);
		while (dir is not null)
		{
			var candidate = Path.Combine(dir.FullName, ".env");
			if (File.Exists(candidate)) return candidate;
			dir = dir.Parent;
		}
		return null;
	}

	private void OnWebResourceRequested(object? sender, CoreWebView2WebResourceRequestedEventArgs args)
	{
		var uri = new Uri(args.Request.Uri);
		if (!uri.Host.Equals("portico.desktop", StringComparison.OrdinalIgnoreCase))
			return;

		var path = uri.AbsolutePath.TrimStart('/');
		if (string.IsNullOrEmpty(path))
			path = "Login.html";

		var resourceName = MapPathToResourceName(path);
		var stream = GetType().Assembly.GetManifestResourceStream(resourceName);
		if (stream is null)
		{
			args.Response = _webView.CoreWebView2.Environment.CreateWebResourceResponse(
				new MemoryStream(0), 404, "Not Found", "Content-Type: text/plain");
			return;
		}

		var mime = GetMimeTypeForWebAsset(path);
		args.Response = _webView.CoreWebView2.Environment.CreateWebResourceResponse(
			stream, 200, "OK", $"Content-Type: {mime}");
	}

	private static string MapPathToResourceName(string path)
	{
		return "webui." + path.Replace('/', '.').Replace('\\', '.');
	}

	private static string GetMimeTypeForWebAsset(string path)
	{
		var extension = Path.GetExtension(path).ToLowerInvariant();
		return extension switch
		{
			".html" => "text/html",
			".css" => "text/css",
			".js" => "application/javascript",
			".json" => "application/json",
			".png" => "image/png",
			".jpg" => "image/jpeg",
			".jpeg" => "image/jpeg",
			".gif" => "image/gif",
			".svg" => "image/svg+xml",
			".ico" => "image/x-icon",
			".woff2" => "font/woff2",
			".woff" => "font/woff",
			".ttf" => "font/ttf",
			_ => "application/octet-stream"
		};
	}

	private async Task HandleDashboardMetricasAsync(JsonElement root)
	{
		var requestId = ReadRequestId(root);
		const string responseType = "dashboard_metricas_response";

		if (!EnsureAutenticado(requestId, responseType))
			return;

		try
		{
			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			// 1. Obras
			int totalObras = 0, obrasActivas = 0;
			await using (var cmd = new MySqlCommand("SELECT COUNT(*), SUM(CASE WHEN activo = 1 THEN 1 ELSE 0 END) FROM obras", conn))
			await using (var reader = await cmd.ExecuteReaderAsync())
			{
				if (await reader.ReadAsync())
				{
					totalObras = reader.IsDBNull(0) ? 0 : Convert.ToInt32(reader[0]);
					obrasActivas = reader.IsDBNull(1) ? 0 : Convert.ToInt32(reader[1]);
				}
			}

			// 2. Obreros
			int totalObreros = 0, obrerosActivos = 0;
			await using (var cmd = new MySqlCommand("SELECT COUNT(*), SUM(CASE WHEN activo = 1 THEN 1 ELSE 0 END) FROM obreros", conn))
			await using (var reader = await cmd.ExecuteReaderAsync())
			{
				if (await reader.ReadAsync())
				{
					totalObreros = reader.IsDBNull(0) ? 0 : Convert.ToInt32(reader[0]);
					obrerosActivos = reader.IsDBNull(1) ? 0 : Convert.ToInt32(reader[1]);
				}
			}

			// 3. Maquinaria
			int totalMaquinaria = 0, maquinariaAsignada = 0;
			await using (var cmd = new MySqlCommand("SELECT COUNT(*), (SELECT COUNT(DISTINCT id_maquinaria) FROM obra_maquinaria WHERE fecha_retiro IS NULL) FROM maquinaria", conn))
			await using (var reader = await cmd.ExecuteReaderAsync())
			{
				if (await reader.ReadAsync())
				{
					totalMaquinaria = reader.IsDBNull(0) ? 0 : Convert.ToInt32(reader[0]);
					maquinariaAsignada = reader.IsDBNull(1) ? 0 : Convert.ToInt32(reader[1]);
				}
			}

			// 4. Horas y registros
			int totalRegistros = 0;
			double totalHoras = 0;
			await using (var cmd = new MySqlCommand("SELECT COUNT(*), COALESCE(SUM(horas_trabajadas), 0) FROM registros", conn))
			await using (var reader = await cmd.ExecuteReaderAsync())
			{
				if (await reader.ReadAsync())
				{
					totalRegistros = reader.IsDBNull(0) ? 0 : Convert.ToInt32(reader[0]);
					totalHoras = reader.IsDBNull(1) ? 0 : Convert.ToDouble(reader[1]);
				}
			}

			// Combustible
			double totalLitrosComb = 0, totalGastoComb = 0, dieselLitros = 0, naftaLitros = 0;
			try
			{
				await using var cmdComb = new MySqlCommand(@"
					SELECT COALESCE(SUM(litros), 0),
					       COALESCE(SUM(precio_total), 0),
					       COALESCE(SUM(CASE WHEN LOWER(nombre_combustible) LIKE '%diesel%' THEN litros ELSE 0 END), 0),
					       COALESCE(SUM(CASE WHEN LOWER(nombre_combustible) LIKE '%nafta%' THEN litros ELSE 0 END), 0)
					FROM combustible", conn);
				await using var reader = await cmdComb.ExecuteReaderAsync();
				if (await reader.ReadAsync())
				{
					totalLitrosComb = reader.IsDBNull(0) ? 0 : Convert.ToDouble(reader[0]);
					totalGastoComb = reader.IsDBNull(1) ? 0 : Convert.ToDouble(reader[1]);
					dieselLitros = reader.IsDBNull(2) ? 0 : Convert.ToDouble(reader[2]);
					naftaLitros = reader.IsDBNull(3) ? 0 : Convert.ToDouble(reader[3]);
				}
			}
			catch { }

			// Actividades / Tareas
			int totalTareas = 0, tareasCompletadas = 0, tareasPendientes = 0;
			double porcentajeAvance = 0;
			try
			{
				await using var cmdTareas = new MySqlCommand(@"
					SELECT COUNT(*),
					       SUM(CASE WHEN estado = 'Completada' THEN 1 ELSE 0 END),
					       SUM(CASE WHEN estado = 'Pendiente' THEN 1 ELSE 0 END)
					FROM contrato_tareas", conn);
				await using var reader = await cmdTareas.ExecuteReaderAsync();
				if (await reader.ReadAsync())
				{
					totalTareas = reader.IsDBNull(0) ? 0 : Convert.ToInt32(reader[0]);
					tareasCompletadas = reader.IsDBNull(1) ? 0 : Convert.ToInt32(reader[1]);
					tareasPendientes = reader.IsDBNull(2) ? 0 : Convert.ToInt32(reader[2]);
					if (totalTareas > 0)
					{
						porcentajeAvance = Math.Round(((double)tareasCompletadas / totalTareas) * 100.0, 1);
					}
				}
			}
			catch { }

			// Recursos
			int totalRecursos = 0, totalMateriales = 0, totalHerramientas = 0;
			try
			{
				await using var cmdRecursos = new MySqlCommand(@"
					SELECT COUNT(*),
					       SUM(CASE WHEN es_material = 1 THEN 1 ELSE 0 END),
					       SUM(CASE WHEN es_material = 0 THEN 1 ELSE 0 END)
					FROM recursos", conn);
				await using var reader = await cmdRecursos.ExecuteReaderAsync();
				if (await reader.ReadAsync())
				{
					totalRecursos = reader.IsDBNull(0) ? 0 : Convert.ToInt32(reader[0]);
					totalMateriales = reader.IsDBNull(1) ? 0 : Convert.ToInt32(reader[1]);
					totalHerramientas = reader.IsDBNull(2) ? 0 : Convert.ToInt32(reader[2]);
				}
			}
			catch { }

			await EnsureNotificacionesLeidasTableAsync(conn);
			var userId = _currentUserId ?? 0;

			// 5. Alertas certificados (no leídas por este usuario)
			int totalAlertasCert = 0, certVencidos = 0, certPorVencer = 0;
			await using (var cmd = new MySqlCommand(@"
				SELECT COUNT(*), 
				       SUM(CASE WHEN c.fecha_vencimiento < CURDATE() THEN 1 ELSE 0 END), 
				       SUM(CASE WHEN c.fecha_vencimiento >= CURDATE() AND c.fecha_vencimiento <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) THEN 1 ELSE 0 END) 
				FROM certificado c
				LEFT JOIN notificaciones_leidas nl ON nl.id_usuario = @userId AND nl.tipo = 'maquinaria' AND nl.id_referencia = c.id_certificado
				WHERE c.fecha_vencimiento IS NOT NULL AND c.fecha_vencimiento <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) AND nl.id_referencia IS NULL", conn))
			{
				cmd.Parameters.AddWithValue("@userId", userId);
				await using var reader = await cmd.ExecuteReaderAsync();
				if (await reader.ReadAsync())
				{
					totalAlertasCert = reader.IsDBNull(0) ? 0 : Convert.ToInt32(reader[0]);
					certVencidos = reader.IsDBNull(1) ? 0 : Convert.ToInt32(reader[1]);
					certPorVencer = reader.IsDBNull(2) ? 0 : Convert.ToInt32(reader[2]);
				}
			}

			// 6. Alertas contratos (no leídas por este usuario)
			int totalAlertasContratos = 0;
			await using (var cmd = new MySqlCommand(@"
				SELECT COUNT(*) 
				FROM contrato_obrero co
				LEFT JOIN notificaciones_leidas nl ON nl.id_usuario = @userId AND nl.tipo = 'obrero' AND nl.id_referencia = co.id_contrato_obrero
				WHERE co.fecha_vencimiento IS NOT NULL AND co.fecha_vencimiento <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) AND nl.id_referencia IS NULL", conn))
			{
				cmd.Parameters.AddWithValue("@userId", userId);
				await using var reader = await cmd.ExecuteReaderAsync();
				if (await reader.ReadAsync())
				{
					totalAlertasContratos = reader.IsDBNull(0) ? 0 : Convert.ToInt32(reader[0]);
				}
			}

			// 7. Distribución cargos
			var distribucionCargos = new List<object>();
			await using (var cmd = new MySqlCommand("SELECT cargo, COUNT(*) FROM obreros WHERE activo = 1 GROUP BY cargo ORDER BY COUNT(*) DESC", conn))
			await using (var reader = await cmd.ExecuteReaderAsync())
			{
				while (await reader.ReadAsync())
				{
					distribucionCargos.Add(new
					{
						cargo = reader.GetString(0),
						cantidad = reader.GetInt32(1)
					});
				}
			}

			// 8. Horas por obra
			var horasPorObra = new List<object>();
			await using (var cmd = new MySqlCommand("SELECT o.nombre, COALESCE(SUM(r.horas_trabajadas), 0) FROM obras o LEFT JOIN registros r ON o.id_obra = r.id_obra WHERE o.activo = 1 GROUP BY o.id_obra, o.nombre ORDER BY COALESCE(SUM(r.horas_trabajadas), 0) DESC LIMIT 5", conn))
			await using (var reader = await cmd.ExecuteReaderAsync())
			{
				while (await reader.ReadAsync())
				{
					horasPorObra.Add(new
					{
						nombre = reader.GetString(0),
						total_horas = reader.GetDouble(1)
					});
				}
			}

			// 9. Alertas recientes (con estado leido por usuario)
			var alertasRecientes = new List<object>();
			await using (var cmd = new MySqlCommand(@"
				SELECT c.id_certificado, c.nombre_archivo, c.fecha_vencimiento, m.nombre, m.marca, 
				       DATEDIFF(c.fecha_vencimiento, CURDATE()),
				       CASE WHEN nl.id_referencia IS NOT NULL THEN 1 ELSE 0 END AS leido
				FROM certificado c 
				JOIN maquinaria m ON c.id_maquinaria = m.id_maquinaria 
				LEFT JOIN notificaciones_leidas nl ON nl.id_usuario = @userId AND nl.tipo = 'maquinaria' AND nl.id_referencia = c.id_certificado
				WHERE c.fecha_vencimiento IS NOT NULL AND c.fecha_vencimiento <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) 
				ORDER BY leido ASC, c.fecha_vencimiento ASC LIMIT 10", conn))
			{
				cmd.Parameters.AddWithValue("@userId", userId);
				await using var reader = await cmd.ExecuteReaderAsync();
				while (await reader.ReadAsync())
				{
					alertasRecientes.Add(new
					{
						id_certificado = reader.GetInt32(0),
						nombre_archivo = reader.IsDBNull(1) ? "" : reader.GetString(1),
						fecha_vencimiento = reader.GetDateTime(2).ToString("yyyy-MM-dd"),
						nombre_maquinaria = reader.GetString(3),
						marca = reader.IsDBNull(4) ? "" : reader.GetString(4),
						dias_restantes = reader.GetInt32(5),
						leido = reader.GetInt32(6)
					});
				}
			}

			// 10. Alertas contratos recientes (con estado leido por usuario)
			var alertasContratos = new List<object>();
			await using (var cmd = new MySqlCommand(@"
				SELECT co.id_contrato_obrero, co.fecha_vencimiento, CONCAT(o.nombre, ' ', COALESCE(o.apellido, '')) AS nombre_obrero, o.documento, 
				       DATEDIFF(co.fecha_vencimiento, CURDATE()) AS dias_restantes, 'obrero' AS tipo_alerta,
				       CASE WHEN nl.id_referencia IS NOT NULL THEN 1 ELSE 0 END AS leido
				FROM contrato_obrero co 
				JOIN obreros o ON co.id_obrero = o.id_obrero 
				LEFT JOIN notificaciones_leidas nl ON nl.id_usuario = @userId AND nl.tipo = 'obrero' AND nl.id_referencia = co.id_contrato_obrero
				WHERE co.fecha_vencimiento IS NOT NULL AND co.fecha_vencimiento <= DATE_ADD(CURDATE(), INTERVAL 30 DAY) 
				ORDER BY leido ASC, co.fecha_vencimiento ASC LIMIT 10", conn))
			{
				cmd.Parameters.AddWithValue("@userId", userId);
				await using var reader = await cmd.ExecuteReaderAsync();
				while (await reader.ReadAsync())
				{
					alertasContratos.Add(new
					{
						id_contrato_obrero = reader.GetInt32(0),
						fecha_vencimiento = reader.GetDateTime(1).ToString("yyyy-MM-dd"),
						nombre_obrero = reader.GetString(2).Trim(),
						documento = reader.IsDBNull(3) ? "" : reader.GetString(3),
						dias_restantes = reader.GetInt32(4),
						tipo_alerta = "obrero",
						leido = reader.GetInt32(6)
					});
				}
			}

			PostToJs(new
			{
				type = responseType,
				requestId,
				success = true,
				data = new
				{
					kpis = new
					{
						obras = new { activas = obrasActivas, total = totalObras },
						obreros = new { activos = obrerosActivos, total = totalObreros },
						maquinaria = new { total = totalMaquinaria, asignada = maquinariaAsignada },
						horas = new { total_horas = totalHoras, total_registros = totalRegistros },
						combustible = new
						{
							total_litros = totalLitrosComb,
							total_gasto = totalGastoComb,
							diesel_litros = dieselLitros,
							nafta_litros = naftaLitros
						},
						actividades = new
						{
							total_tareas = totalTareas,
							tareas_completadas = tareasCompletadas,
							tareas_pendientes = tareasPendientes,
							porcentaje_avance = porcentajeAvance
						},
						recursos = new
						{
							total_recursos = totalRecursos,
							total_materiales = totalMateriales,
							total_herramientas = totalHerramientas
						},
						alertas = new
						{
							certificados = totalAlertasCert,
							cert_vencidos = certVencidos,
							cert_por_vencer = certPorVencer,
							contratos = totalAlertasContratos
						}
					},
					distribucion_cargos = distribucionCargos,
					horas_por_obra = horasPorObra,
					alertas_recientes = alertasRecientes,
					alertas_contratos = alertasContratos
				}
			});
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Dashboard error] {ex}");
			PostToJs(new { type = responseType, requestId, success = false, error = "Error al obtener métricas del dashboard." });
		}
	}

	private static async Task EnsureNotificacionesLeidasTableAsync(MySqlConnection conn)
	{
		const string sql = @"
			CREATE TABLE IF NOT EXISTS notificaciones_leidas (
				id_usuario INT NOT NULL,
				tipo VARCHAR(20) NOT NULL,
				id_referencia INT NOT NULL,
				fecha_leido DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
				PRIMARY KEY (id_usuario, tipo, id_referencia),
				INDEX idx_notif_usuario (id_usuario)
			) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
		await using var cmd = new MySqlCommand(sql, conn);
		await cmd.ExecuteNonQueryAsync();
	}

	private async Task HandleNotificacionMarcarLeidaAsync(JsonElement root)
	{
		var requestId = ReadRequestId(root);
		const string responseType = "notificacion_marcar_leida_response";

		if (!EnsureAutenticado(requestId, responseType))
			return;

		var userId = _currentUserId ?? 0;
		if (userId <= 0)
		{
			PostToJs(new { type = responseType, requestId, success = false, error = "Sesión no válida." });
			return;
		}

		var tipo = root.TryGetProperty("tipo", out var tipoProp) ? tipoProp.GetString()?.Trim() ?? string.Empty : string.Empty;
		int idReferencia = 0;
		if (root.TryGetProperty("id_referencia", out var idRefProp))
		{
			if (idRefProp.ValueKind == JsonValueKind.Number)
				idReferencia = idRefProp.GetInt32();
			else if (idRefProp.ValueKind == JsonValueKind.String && int.TryParse(idRefProp.GetString(), out var parsed))
				idReferencia = parsed;
		}

		try
		{
			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();
			await EnsureNotificacionesLeidasTableAsync(conn);

			if (tipo == "todas")
			{
				const string sqlTodasCert = @"
					INSERT IGNORE INTO notificaciones_leidas (id_usuario, tipo, id_referencia)
					SELECT @userId, 'maquinaria', id_certificado
					FROM certificado
					WHERE fecha_vencimiento IS NOT NULL AND fecha_vencimiento <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)";
				await using (var cmd = new MySqlCommand(sqlTodasCert, conn))
				{
					cmd.Parameters.AddWithValue("@userId", userId);
					await cmd.ExecuteNonQueryAsync();
				}

				const string sqlTodasObreros = @"
					INSERT IGNORE INTO notificaciones_leidas (id_usuario, tipo, id_referencia)
					SELECT @userId, 'obrero', id_contrato_obrero
					FROM contrato_obrero
					WHERE fecha_vencimiento IS NOT NULL AND fecha_vencimiento <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)";
				await using (var cmd = new MySqlCommand(sqlTodasObreros, conn))
				{
					cmd.Parameters.AddWithValue("@userId", userId);
					await cmd.ExecuteNonQueryAsync();
				}

				PostToJs(new { type = responseType, requestId, success = true, message = "Todas las notificaciones fueron marcadas como leídas." });
				return;
			}

			if ((tipo != "maquinaria" && tipo != "obrero") || idReferencia <= 0)
			{
				PostToJs(new { type = responseType, requestId, success = false, error = "Parámetros inválidos." });
				return;
			}

			const string sqlInsert = @"
				INSERT IGNORE INTO notificaciones_leidas (id_usuario, tipo, id_referencia)
				VALUES (@userId, @tipo, @idReferencia)";
			await using (var cmd = new MySqlCommand(sqlInsert, conn))
			{
				cmd.Parameters.AddWithValue("@userId", userId);
				cmd.Parameters.AddWithValue("@tipo", tipo);
				cmd.Parameters.AddWithValue("@idReferencia", idReferencia);
				await cmd.ExecuteNonQueryAsync();
			}

			PostToJs(new { type = responseType, requestId, success = true, message = "Notificación marcada como leída." });
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[MarcarNotificacion error] {ex}");
			PostToJs(new { type = responseType, requestId, success = false, error = "Error al actualizar notificación." });
		}
	}

	private async Task HandleConsultasBuscarAsync(JsonElement root)
	{
		var requestId = ReadRequestId(root);
		const string responseType = "consultas_buscar_response";

		if (!EnsureAutenticado(requestId, responseType))
			return;

		int idObrero = 0;
		if (root.TryGetProperty("id_obrero", out var obreroProp))
		{
			if (obreroProp.ValueKind == JsonValueKind.Number)
				idObrero = obreroProp.GetInt32();
			else if (obreroProp.ValueKind == JsonValueKind.String && int.TryParse(obreroProp.GetString(), out var parsedObrero))
				idObrero = parsedObrero;
		}

		var fechaDesde = root.TryGetProperty("fecha_desde", out var fdProp) ? fdProp.GetString()?.Trim() ?? string.Empty : string.Empty;
		var fechaHasta = root.TryGetProperty("fecha_hasta", out var fhProp) ? fhProp.GetString()?.Trim() ?? string.Empty : string.Empty;

		int page = 1;
		if (root.TryGetProperty("page", out var pageProp) && pageProp.TryGetInt32(out var pVal))
			page = Math.Max(1, pVal);

		int limit = 10;
		if (root.TryGetProperty("limit", out var limitProp) && limitProp.TryGetInt32(out var lVal))
			limit = Math.Clamp(lVal, 1, 100);

		var whereClauses = new List<string>();
		if (idObrero > 0)
		{
			whereClauses.Add("r.id_obrero = @idObrero");
		}
		if (!string.IsNullOrEmpty(fechaDesde) && !string.IsNullOrEmpty(fechaHasta))
		{
			whereClauses.Add("r.fecha BETWEEN @fechaDesde AND @fechaHasta");
		}

		if (whereClauses.Count == 0)
		{
			PostToJs(new { type = responseType, requestId, success = false, error = "Seleccione al menos un obrero o un período." });
			return;
		}

		var whereSql = string.Join(" AND ", whereClauses);

		try
		{
			await using var conn = new MySqlConnection(BuildConnectionString());
			await conn.OpenAsync();

			// 1. Resumen
			int totalObras = 0;
			int diasTrabajados = 0;
			double totalHoras = 0;

			var sqlResumen = $@"
				SELECT
					COUNT(DISTINCT r.id_obra) AS total_obras,
					COUNT(*) AS dias_trabajados,
					COALESCE(SUM(r.horas_trabajadas), 0) AS total_horas
				FROM registros r
				WHERE {whereSql}";

			await using (var cmdResumen = new MySqlCommand(sqlResumen, conn))
			{
				if (idObrero > 0) cmdResumen.Parameters.AddWithValue("@idObrero", idObrero);
				if (!string.IsNullOrEmpty(fechaDesde) && !string.IsNullOrEmpty(fechaHasta))
				{
					cmdResumen.Parameters.AddWithValue("@fechaDesde", fechaDesde);
					cmdResumen.Parameters.AddWithValue("@fechaHasta", fechaHasta);
				}

				await using var reader = await cmdResumen.ExecuteReaderAsync();
				if (await reader.ReadAsync())
				{
					totalObras = reader.IsDBNull(0) ? 0 : Convert.ToInt32(reader[0]);
					diasTrabajados = reader.IsDBNull(1) ? 0 : Convert.ToInt32(reader[1]);
					totalHoras = reader.IsDBNull(2) ? 0 : Convert.ToDouble(reader[2]);
				}
			}

			// 2. Conteo total de registros
			int totalRegistros = 0;
			var sqlCount = $@"
				SELECT COUNT(*)
				FROM registros r
				INNER JOIN obras o ON o.id_obra = r.id_obra
				WHERE {whereSql}";

			await using (var cmdCount = new MySqlCommand(sqlCount, conn))
			{
				if (idObrero > 0) cmdCount.Parameters.AddWithValue("@idObrero", idObrero);
				if (!string.IsNullOrEmpty(fechaDesde) && !string.IsNullOrEmpty(fechaHasta))
				{
					cmdCount.Parameters.AddWithValue("@fechaDesde", fechaDesde);
					cmdCount.Parameters.AddWithValue("@fechaHasta", fechaHasta);
				}

				var countObj = await cmdCount.ExecuteScalarAsync();
				totalRegistros = countObj != null && countObj != DBNull.Value ? Convert.ToInt32(countObj) : 0;
			}

			int totalPages = Math.Max(1, (int)Math.Ceiling((double)totalRegistros / limit));
			page = Math.Min(page, totalPages);
			int offset = (page - 1) * limit;

			// 3. Listado paginado
			var registros = new List<object>();
			var sqlListado = $@"
				SELECT
					r.fecha,
					o.nombre AS obra,
					r.hora_entrada,
					r.hora_salida,
					r.horas_trabajadas
				FROM registros r
				INNER JOIN obras o ON o.id_obra = r.id_obra
				WHERE {whereSql}
				ORDER BY r.fecha DESC
				LIMIT @limit OFFSET @offset";

			await using (var cmdList = new MySqlCommand(sqlListado, conn))
			{
				if (idObrero > 0) cmdList.Parameters.AddWithValue("@idObrero", idObrero);
				if (!string.IsNullOrEmpty(fechaDesde) && !string.IsNullOrEmpty(fechaHasta))
				{
					cmdList.Parameters.AddWithValue("@fechaDesde", fechaDesde);
					cmdList.Parameters.AddWithValue("@fechaHasta", fechaHasta);
				}
				cmdList.Parameters.AddWithValue("@limit", limit);
				cmdList.Parameters.AddWithValue("@offset", offset);

				await using var reader = await cmdList.ExecuteReaderAsync();
				while (await reader.ReadAsync())
				{
					var fechaStr = reader.IsDBNull(0) ? "" : reader.GetDateTime(0).ToString("yyyy-MM-dd");
					var obraStr = reader.IsDBNull(1) ? "" : reader.GetString(1);
					var entradaStr = reader.IsDBNull(2) ? "" : (reader.GetValue(2) is TimeSpan tsIn ? tsIn.ToString(@"hh\:mm") : reader.GetValue(2).ToString() ?? "");
					var salidaStr = reader.IsDBNull(3) ? "" : (reader.GetValue(3) is TimeSpan tsOut ? tsOut.ToString(@"hh\:mm") : reader.GetValue(3).ToString() ?? "");
					var horasVal = reader.IsDBNull(4) ? 0d : Convert.ToDouble(reader.GetValue(4));

					registros.Add(new
					{
						fecha = fechaStr,
						obra = obraStr,
						hora_entrada = entradaStr,
						hora_salida = salidaStr,
						horas_trabajadas = horasVal
					});
				}
			}

			PostToJs(new
			{
				type = responseType,
				requestId,
				success = true,
				resumen = new
				{
					total_obras = totalObras,
					dias_trabajados = diasTrabajados,
					total_horas = totalHoras
				},
				registros,
				total = totalRegistros,
				page,
				per_page = limit,
				total_pages = totalPages
			});
		}
		catch (Exception ex)
		{
			System.Diagnostics.Debug.WriteLine($"[Consultas error] {ex}");
			PostToJs(new { type = responseType, requestId, success = false, error = "Error al buscar consultas." });
		}
	}

	private void ShowError(string message)
	{
		var safe = message.Replace("<", "&lt;").Replace(">", "&gt;");
		_webView.NavigateToString($"<html><body style='font-family:Segoe UI;padding:20px;'><h2>Portico Desktop</h2><p>{safe}</p></body></html>");
	}
}
