<?php

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/session.php';
require_once __DIR__ . '/config/auditoria.php';

$origin = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
    . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');

header("Access-Control-Allow-Origin: {$origin}");
header('Access-Control-Allow-Credentials: true');
header('Access-Control-Allow-Headers: Content-Type, X-CSRF-Token');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

iniciarSesion();

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Sesión no válida. Iniciá sesión nuevamente.']);
    exit;
}

$esAdmin = ($_SESSION['rol'] ?? '') === 'Administrador';

try {
    $pdo = conectar();

    switch ($_SERVER['REQUEST_METHOD']) {
        case 'GET':
            if (isset($_GET['descargar_contrato'])) {
                responderDescargaContratoObrero($pdo);
                break;
            }
            if (isset($_GET['id_obrero_contratos'])) {
                responderListadoContratosObrero($pdo);
                break;
            }
            responderListado($pdo);
            break;

        case 'POST':
            if (!$esAdmin) {
                http_response_code(403);
                echo json_encode(['error' => 'No tenés permisos para gestionar obreros.']);
                exit;
            }
            validarCsrf();
            verificarLimitePost();
            if (isset($_POST['accion']) && $_POST['accion'] === 'subir_contrato') {
                responderSubirContrato($pdo);
                break;
            }
            $body = leerJson();
            if (($body['accion'] ?? '') === 'eliminar_contrato') {
                responderEliminarContrato($pdo, $body);
                break;
            }
            if (($body['accion'] ?? '') === 'editar_fecha_contrato') {
                responderEditarFechaContrato($pdo, $body);
                break;
            }
            if (($body['accion'] ?? '') === 'subir_contrato_base64') {
                responderSubirContratoBase64($pdo, $body);
                break;
            }
            responderGuardado($pdo, $body);
            break;

        case 'DELETE':
            if (!$esAdmin) {
                http_response_code(403);
                echo json_encode(['error' => 'No tenés permisos para gestionar obreros.']);
                exit;
            }
            validarCsrf();
            $body = leerJson();
            responderEliminacion($pdo, $body);
            break;

        default:
            http_response_code(405);
            echo json_encode(['error' => 'Método no permitido']);
    }
} catch (InvalidArgumentException $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
} catch (RuntimeException $e) {
    http_response_code(404);
    echo json_encode(['error' => $e->getMessage()]);
} catch (PDOException $e) {
    if ((int) $e->getCode() === 23000) {
        http_response_code(409);
        echo json_encode(['error' => 'Ya existe un obrero con ese documento.']);
        exit;
    }

    error_log('obreros.php PDO error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Error interno del servidor.']);
} catch (Throwable $e) {
    error_log('obreros.php error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Error interno del servidor.']);
}

function responderListado(PDO $pdo): void
{
    $page = max(1, (int) ($_GET['page'] ?? 1));
    $limit = (int) ($_GET['limit'] ?? 10);
    $limit = max(1, min($limit, 100));
    $search = trim((string) ($_GET['search'] ?? ''));
    $filtroContrato = $_GET['filtro_contrato'] ?? 'todos';

    $where = ['activo = 1'];
    $params = [];

    // Filtro por búsqueda
    if ($search !== '') {
        $where[] = '(nombre LIKE ? OR apellido LIKE ? OR documento LIKE ? OR telefono LIKE ? OR cargo LIKE ?)';
        $searchLike = '%' . $search . '%';
        $params = array_merge($params, [$searchLike, $searchLike, $searchLike, $searchLike, $searchLike]);
    }

    // Filtro por estado del contrato (usa fecha_fin del obrero)
    if ($filtroContrato === 'vencido') {
        $where[] = 'o.fecha_fin IS NOT NULL AND o.fecha_fin < CURDATE()';
    } elseif ($filtroContrato === 'por_vencer') {
        $where[] = 'o.fecha_fin IS NOT NULL AND o.fecha_fin BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)';
    } elseif ($filtroContrato === 'vigente') {
        $where[] = '(o.fecha_fin IS NULL OR o.fecha_fin > DATE_ADD(CURDATE(), INTERVAL 30 DAY))';
    }
    // 'todos' no agrega condición extra

    $whereSql = ' WHERE ' . implode(' AND ', $where);

    // Contar total
    $countStmt = $pdo->prepare('SELECT COUNT(*) FROM obreros o' . $whereSql);
    foreach ($params as $index => $value) {
        $countStmt->bindValue($index + 1, $value, PDO::PARAM_STR);
    }
    $countStmt->execute();
    $total = (int) $countStmt->fetchColumn();

    $totalPages = max(1, (int) ceil($total / $limit));
    $page = min($page, $totalPages);
    $offset = ($page - 1) * $limit;

    $stmt = $pdo->prepare(
        'SELECT o.id_obrero, o.nombre, o.apellido, o.documento, o.telefono, o.fecha_contratacion, o.fecha_fin, o.cargo,
                (SELECT c.fecha_vencimiento FROM contrato_obrero c WHERE c.id_obrero = o.id_obrero ORDER BY c.fecha_vencimiento DESC LIMIT 1) as vencimiento
         FROM obreros o'
        . $whereSql
        . ' ORDER BY o.id_obrero DESC LIMIT ? OFFSET ?'
    );

    $bindIndex = 1;
    foreach ($params as $value) {
        $stmt->bindValue($bindIndex++, $value, PDO::PARAM_STR);
    }
    $stmt->bindValue($bindIndex++, $limit, PDO::PARAM_INT);
    $stmt->bindValue($bindIndex, $offset, PDO::PARAM_INT);
    $stmt->execute();

    echo json_encode([
        'success' => true,
        'obreros' => $stmt->fetchAll(),
        'total' => $total,
        'page' => $page,
        'per_page' => $limit,
        'total_pages' => $totalPages,
        'filtro_contrato' => $filtroContrato,
    ]);
}

// El resto de las funciones (responderGuardado, responderEliminacion, responderSubirContrato, validarCsrf, etc.)
// se mantienen exactamente igual que en tu código original.
// Por brevedad no las repito aquí, pero van debajo sin cambios.

function responderGuardado(PDO $pdo, array $body): void
{
    $nombre = limpiarTexto($body['nombre'] ?? '', 150, true);
    $apellido = limpiarTexto($body['apellido'] ?? '', 100, false);
    $documento = limpiarTexto($body['documento'] ?? '', 30, true);
    $telefono = limpiarTexto($body['telefono'] ?? '', 30, false);
    $fechaContratacion = normalizarFecha($body['fecha_contratacion'] ?? null);
    $fechaFin = normalizarFecha($body['fecha_fin'] ?? null);
    $cargo = limpiarTexto($body['cargo'] ?? '', 50, false) ?: 'Peón';
    $idObrero = isset($body['id_obrero']) && $body['id_obrero'] !== '' ? (int) $body['id_obrero'] : null;

    if ($nombre === '' || $documento === '') {
        throw new InvalidArgumentException('Nombre y documento son obligatorios.');
    }

    $pdo->beginTransaction();

    try {
        if ($idObrero !== null) {
            $stmt = $pdo->prepare('SELECT id_obrero FROM obreros WHERE id_obrero = ? LIMIT 1');
            $stmt->execute([$idObrero]);

            if (!$stmt->fetchColumn()) {
                throw new RuntimeException('El obrero indicado no existe.');
            }

            $stmt = $pdo->prepare(
                'UPDATE obreros SET nombre = ?, apellido = ?, documento = ?, telefono = ?, fecha_contratacion = ?, fecha_fin = ?, cargo = ? WHERE id_obrero = ?'
            );
            $stmt->execute([$nombre, $apellido, $documento, $telefono, $fechaContratacion, $fechaFin, $cargo, $idObrero]);

            $pdo->commit();

            $obreroRespuesta = obtenerObrero($pdo, $idObrero);
            registrarAuditoria($pdo, 'editar', 'obreros', $idObrero, ['nombre' => $obreroRespuesta['nombre'], 'apellido' => $obreroRespuesta['apellido']]);

            http_response_code(200);
            echo json_encode([
                'success' => true,
                'message' => 'Obrero actualizado correctamente.',
                'obrero' => $obreroRespuesta,
            ]);
            return;
        }

        $stmt = $pdo->prepare(
            'INSERT INTO obreros (nombre, apellido, documento, telefono, fecha_contratacion, fecha_fin, cargo, activo) VALUES (?, ?, ?, ?, ?, ?, ?, 1)'
        );
        $stmt->execute([$nombre, $apellido, $documento, $telefono, $fechaContratacion, $fechaFin, $cargo]);

        $idObrero = (int) $pdo->lastInsertId();

        $pdo->commit();

        $obreroRespuesta = obtenerObrero($pdo, $idObrero);
        registrarAuditoria($pdo, 'crear', 'obreros', $idObrero, ['nombre' => $obreroRespuesta['nombre'], 'apellido' => $obreroRespuesta['apellido']]);

        http_response_code(201);
        echo json_encode([
            'success' => true,
            'message' => 'Obrero registrado correctamente.',
            'obrero' => $obreroRespuesta,
        ]);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function responderEliminacion(PDO $pdo, array $body): void
{
    $idObrero = isset($body['id_obrero']) ? (int) $body['id_obrero'] : 0;
    if ($idObrero <= 0) {
        throw new InvalidArgumentException('Debés indicar un obrero válido.');
    }

    $stmt = $pdo->prepare('SELECT id_obrero, nombre, apellido FROM obreros WHERE id_obrero = ? LIMIT 1');
    $stmt->execute([$idObrero]);
    $obrero = $stmt->fetch();
    if (!$obrero) {
        throw new RuntimeException('El obrero indicado no existe.');
    }

    $pdo->prepare('UPDATE obreros SET activo = 0 WHERE id_obrero = ?')->execute([$idObrero]);

    registrarAuditoria($pdo, 'eliminar', 'obreros', $idObrero, ['nombre' => $obrero['nombre'], 'apellido' => $obrero['apellido']]);

    echo json_encode([
        'success' => true,
        'message' => 'Obrero eliminado correctamente.',
    ]);
}

function responderSubirContrato(PDO $pdo): void
{
    $idObrero = isset($_POST['id_obrero']) ? (int) $_POST['id_obrero'] : 0;
    $fechaVencimiento = normalizarFecha($_POST['fecha_vencimiento'] ?? null);

    if ($idObrero <= 0) {
        throw new InvalidArgumentException('Debés indicar un obrero válido.');
    }
    if (empty($fechaVencimiento)) {
        throw new InvalidArgumentException('Debés indicar una fecha de vencimiento.');
    }
    if (!isset($_FILES['contrato'])) {
        throw new InvalidArgumentException('No se seleccionó ningún archivo de contrato.');
    }

    $fileError = $_FILES['contrato']['error'];
    if ($fileError !== UPLOAD_ERR_OK) {
        if ($fileError === UPLOAD_ERR_INI_SIZE || $fileError === UPLOAD_ERR_FORM_SIZE) {
            throw new InvalidArgumentException('El contrato subido supera el tamaño máximo permitido por el servidor.');
        }
        if ($fileError === UPLOAD_ERR_NO_FILE) {
            throw new InvalidArgumentException('No se seleccionó ningún archivo de contrato.');
        }
        throw new InvalidArgumentException('Error al subir el archivo (código ' . $fileError . ').');
    }

    if (($_FILES['contrato']['size'] ?? 0) > 10 * 1024 * 1024) {
        throw new InvalidArgumentException('El contrato no puede superar los 10 MB.');
    }

    $nombreOriginal = $_FILES['contrato']['name'];
    validarExtensionContrato($nombreOriginal);

    $archivoContenido = file_get_contents($_FILES['contrato']['tmp_name']);
    if ($archivoContenido === false || strlen($archivoContenido) === 0) {
        throw new InvalidArgumentException('No se pudo leer el archivo del contrato.');
    }

    if (strlen($archivoContenido) > 10 * 1024 * 1024) {
        throw new InvalidArgumentException('El contrato no puede superar los 10 MB.');
    }

    $stmt = $pdo->prepare('INSERT INTO contrato_obrero (archivo, nombre_archivo, id_obrero, fecha_vencimiento) VALUES (?, ?, ?, ?)');
    $stmt->bindValue(1, $archivoContenido, PDO::PARAM_LOB);
    $stmt->bindValue(2, $nombreOriginal);
    $stmt->bindValue(3, $idObrero, PDO::PARAM_INT);
    $stmt->bindValue(4, $fechaVencimiento);
    $stmt->execute();

    registrarAuditoria($pdo, 'subir_contrato', 'contrato_obrero', $idObrero, ['nombre_archivo' => $nombreOriginal, 'fecha_vencimiento' => $fechaVencimiento]);

    echo json_encode([
        'success' => true,
        'message' => 'Contrato subido correctamente.',
    ]);
}

function validarCsrf(): void
{
    $csrfRecibido = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    $csrfGuardado = $_SESSION['csrf_token'] ?? '';

    if ($csrfGuardado === '' || !hash_equals($csrfGuardado, $csrfRecibido)) {
        http_response_code(403);
        echo json_encode(['error' => 'Token de seguridad inválido. Recargá la página.']);
        exit;
    }
}

function leerJson(): array
{
    $body = json_decode(file_get_contents('php://input'), true);
    if (!is_array($body)) {
        throw new InvalidArgumentException('Cuerpo de solicitud inválido.');
    }
    return $body;
}

function limpiarTexto(mixed $value, int $maxLength, bool $required = true): ?string
{
    $text = trim((string) $value);
    if ($text === '') {
        return $required ? '' : null;
    }

    $length = function_exists('mb_strlen') ? mb_strlen($text) : strlen($text);
    if ($length > $maxLength) {
        throw new InvalidArgumentException('Uno de los campos supera la longitud permitida.');
    }

    return $text;
}

function normalizarFecha(mixed $value): ?string
{
    $text = trim((string) ($value ?? ''));
    if ($text === '') {
        return null;
    }

    $date = DateTime::createFromFormat('Y-m-d', $text);
    $errors = DateTime::getLastErrors();

    if (!$date || ($errors['warning_count'] ?? 0) > 0 || ($errors['error_count'] ?? 0) > 0) {
        throw new InvalidArgumentException('Formato de fecha inválido.');
    }

    return $date->format('Y-m-d');
}

function obtenerObrero(PDO $pdo, int $idObrero): array
{
    $stmt = $pdo->prepare(
        'SELECT id_obrero, nombre, apellido, documento, telefono, fecha_contratacion, fecha_fin, cargo FROM obreros WHERE id_obrero = ? LIMIT 1'
    );
    $stmt->execute([$idObrero]);

    $obrero = $stmt->fetch();
    if (!$obrero) {
        throw new RuntimeException('El obrero indicado no existe.');
    }

    return $obrero;
}

function responderListadoContratosObrero(PDO $pdo): void
{
    $id = (int) ($_GET['id_obrero_contratos'] ?? 0);
    if ($id <= 0) {
        throw new InvalidArgumentException('Obrero inválido');
    }

    $stmt = $pdo->prepare('SELECT id_contrato_obrero, nombre_archivo, fecha_vencimiento FROM contrato_obrero WHERE id_obrero = ? ORDER BY fecha_vencimiento DESC, id_contrato_obrero DESC');
    $stmt->execute([$id]);

    echo json_encode([
        'success' => true,
        'contratos' => $stmt->fetchAll()
    ]);
}

function responderDescargaContratoObrero(PDO $pdo): void
{
    $idContrato = isset($_GET['descargar_contrato']) ? (int) $_GET['descargar_contrato'] : 0;
    if ($idContrato <= 0) {
        throw new InvalidArgumentException('Debés indicar un contrato válido.');
    }

    $stmt = $pdo->prepare('SELECT archivo, nombre_archivo FROM contrato_obrero WHERE id_contrato_obrero = ? LIMIT 1');
    $stmt->execute([$idContrato]);
    $contrato = $stmt->fetch();

    if (!$contrato) {
        throw new RuntimeException('El contrato indicado no existe.');
    }

    $nombreArchivo = $contrato['nombre_archivo'] ?? "contrato-{$idContrato}";
    $archivo = $contrato['archivo'];

    echo json_encode([
        'success' => true,
        'nombre_archivo' => $nombreArchivo,
        'tipo_contenido' => guessMimeTypeContrato($nombreArchivo),
        'contenido_base64' => base64_encode($archivo),
    ]);
}

function responderEliminarContrato(PDO $pdo, array $body): void
{
    $id = (int) ($body['id_contrato_obrero'] ?? 0);

    $stmt = $pdo->prepare('SELECT id_contrato_obrero, id_obrero, nombre_archivo FROM contrato_obrero WHERE id_contrato_obrero = ? LIMIT 1');
    $stmt->execute([$id]);
    $contrato = $stmt->fetch();
    if (!$contrato) {
        throw new RuntimeException('El contrato indicado no existe.');
    }

    $pdo->prepare('DELETE FROM contrato_obrero WHERE id_contrato_obrero = ?')->execute([$id]);

    registrarAuditoria($pdo, 'eliminar_contrato', 'contrato_obrero', $contrato['id_obrero'], [
        'nombre_archivo' => $contrato['nombre_archivo'],
        'id_contrato_obrero' => $id,
    ]);

    echo json_encode(['success' => true, 'message' => 'Contrato eliminado correctamente.']);
}

function responderEditarFechaContrato(PDO $pdo, array $body): void
{
    $id = (int) ($body['id_contrato_obrero'] ?? 0);
    $fecha = normalizarFecha($body['fecha_vencimiento'] ?? null);

    if ($id <= 0) {
        throw new InvalidArgumentException('Debés indicar un contrato válido.');
    }

    $stmt = $pdo->prepare('SELECT id_contrato_obrero, id_obrero FROM contrato_obrero WHERE id_contrato_obrero = ? LIMIT 1');
    $stmt->execute([$id]);
    $contrato = $stmt->fetch();
    if (!$contrato) {
        throw new RuntimeException('El contrato indicado no existe.');
    }

    $stmt = $pdo->prepare('UPDATE contrato_obrero SET fecha_vencimiento = ? WHERE id_contrato_obrero = ?');
    $stmt->execute([$fecha, $id]);

    registrarAuditoria($pdo, 'editar_contrato', 'contrato_obrero', $contrato['id_obrero'], [
        'id_contrato_obrero' => $id,
        'fecha_vencimiento' => $fecha,
    ]);

    echo json_encode(['success' => true, 'message' => 'Fecha de vencimiento actualizada.']);
}

function responderSubirContratoBase64(PDO $pdo, array $body): void
{
    $id = (int) ($body['id_obrero'] ?? 0);
    $nombre = trim($body['nombre_archivo'] ?? '');
    $fecha = normalizarFecha($body['fecha_vencimiento'] ?? null);
    $archivo = base64_decode($body['contenido_base64'] ?? '', true);

    if ($id <= 0 || !$archivo) {
        throw new InvalidArgumentException('Datos de contrato inválidos.');
    }

    if (strlen($archivo) > 10 * 1024 * 1024) {
        throw new InvalidArgumentException('El contrato no puede superar los 10 MB.');
    }

    validarExtensionContrato($nombre);

    $stmt = $pdo->prepare('INSERT INTO contrato_obrero (archivo, nombre_archivo, id_obrero, fecha_vencimiento) VALUES (?, ?, ?, ?)');
    $stmt->bindValue(1, $archivo, PDO::PARAM_LOB);
    $stmt->bindValue(2, $nombre);
    $stmt->bindValue(3, $id, PDO::PARAM_INT);
    $stmt->bindValue(4, $fecha);
    $stmt->execute();

    registrarAuditoria($pdo, 'subir_contrato', 'contrato_obrero', $id, [
        'nombre_archivo' => $nombre,
        'fecha_vencimiento' => $fecha,
    ]);

    echo json_encode(['success' => true, 'message' => 'Contrato subido correctamente.']);
}

function guessMimeTypeContrato(string $nombreArchivo): string
{
    $extension = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));
    return match ($extension) {
        'pdf' => 'application/pdf',
        'doc' => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'jpg', 'jpeg' => 'image/jpeg',
        'png' => 'image/png',
        default => 'application/octet-stream',
    };
}
?>