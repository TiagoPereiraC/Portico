const panelObreros = document.getElementById("panelObreros");
const panelRegistro = document.getElementById("panelRegistro");
const openRegisterPanel = document.getElementById("openRegisterPanel");
const cancelRegisterPanel = document.getElementById("cancelRegisterPanel");
const obreroForm = document.getElementById("obreroForm");
const formTitle = document.getElementById("formTitle");
const btnGuardar = document.getElementById("btnGuardar");
const obreroTableBody = document.getElementById("obreroTableBody");
const searchObreros = document.getElementById("searchObreros");
const tableWrap = document.getElementById("tableWrap");
const loadingState = document.getElementById("loadingState");
const emptyState = document.getElementById("emptyState");
const emptyStateMessage = document.getElementById("emptyStateMessage");
const resultsCount = document.getElementById("resultsCount");
const pagination = document.getElementById("pagination");
const paginationInfo = document.getElementById("paginationInfo");
const paginationPage = document.getElementById("paginationPage");
const paginationPrev = document.getElementById("paginationPrev");
const paginationNext = document.getElementById("paginationNext");
const feedbackPanel = document.getElementById("feedbackPanel");
const feedbackTitle = document.getElementById("feedbackTitle");
const feedbackMessage = document.getElementById("feedbackMessage");
const feedbackClose = document.getElementById("feedbackClose");
const confirmModal = document.getElementById("confirmModal");
const confirmTitle = document.getElementById("confirmTitle");
const confirmMessage = document.getElementById("confirmMessage");
const confirmCancel = document.getElementById("confirmCancel");
const confirmAccept = document.getElementById("confirmAccept");
const contratoModal = document.getElementById("contratoModal");
const contratoModalTitle = document.getElementById("contratoModalTitle");
const contratoForm = document.getElementById("contratoForm");
const contratoCancel = document.getElementById("contratoCancel");
const contratoAccept = document.getElementById("contratoAccept");
const contratoFileInput = document.getElementById("contrato_file");
const contratoFileName = document.getElementById("contratoFileName");
const contratoLista = document.getElementById("contratoLista");

// NUEVO: Elementos del filtro de contrato
const filtroButtons = document.querySelectorAll("[data-filtro-contrato]");
let filtroContrato = "todos"; // valores: todos, vencido, por_vencer, vigente

const MAX_CONTRATO_SIZE = 10 * 1024 * 1024; // 10 MB

function validarArchivoContrato(file) {
  if (!file) {
    throw new Error("Debés seleccionar un archivo.");
  }
  if (file.size > MAX_CONTRATO_SIZE) {
    const sizeMb = (file.size / (1024 * 1024)).toFixed(2);
    throw new Error(`El contrato no puede superar los 10 MB (el archivo seleccionado pesa ${sizeMb} MB).`);
  }
  const ext = (file.name.split(".").pop() || "").toLowerCase();
  const permitidas = ["pdf", "doc", "docx", "jpg", "jpeg", "png"];
  if (!permitidas.includes(ext)) {
    throw new Error("Formato de archivo no permitido. Solo se aceptan PDF, DOC, DOCX, JPG o PNG.");
  }
  return true;
}

const isDesktopWebView = Boolean(window.chrome?.webview);

function resolveApiBase() {
  if (!window.location.protocol.startsWith("http")) {
    return null;
  }
  const path = window.location.pathname;
  const idx = path.lastIndexOf("/web-ui/");
  if (idx !== -1) {
    return window.location.origin + path.substring(0, idx) + "/api";
  }
  return window.location.origin + "/api";
}

const apiBase = resolveApiBase();
const OBREROS_POR_PAGINA = 10;

let csrfToken = "";
let obreros = [];
let totalObreros = 0;
let totalPaginas = 1;
let obreroEnEdicion = null;
let confirmAction = null;
let paginaActual = 1;
let terminoBusqueda = "";
let busquedaTimeoutId = null;
let ultimaSolicitudListado = 0;

// NUEVO: Listeners para los botones de filtro
if (filtroButtons.length) {
  filtroButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const nuevoFiltro = btn.dataset.filtroContrato;
      if (nuevoFiltro === filtroContrato) return;
      filtroContrato = nuevoFiltro;
      // Actualizar estilo activo
      filtroButtons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      paginaActual = 1;
      cargarObreros();
    });
  });
}

feedbackClose.addEventListener("click", ocultarFeedback);
confirmCancel.addEventListener("click", cerrarConfirmacion);
confirmAccept.addEventListener("click", async () => {
  if (!confirmAction) {
    cerrarConfirmacion();
    return;
  }
  confirmAccept.disabled = true;
  try {
    await confirmAction();
  } finally {
    confirmAccept.disabled = false;
    cerrarConfirmacion();
  }
});
confirmModal.addEventListener("click", (event) => {
  if (event.target === confirmModal) {
    cerrarConfirmacion();
  }
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !confirmModal.classList.contains("hidden")) {
    cerrarConfirmacion();
  }
  if (event.key === "Escape" && !contratoModal.classList.contains("hidden")) {
    cerrarContratoModal();
  }
});
contratoCancel.addEventListener("click", cerrarContratoModal);
contratoModal.addEventListener("click", (event) => {
  if (event.target === contratoModal) {
    cerrarContratoModal();
  }
});
contratoFileInput.addEventListener("change", () => {
  const file = contratoFileInput.files?.[0];
  contratoFileName.textContent = file ? file.name : "Ningún archivo seleccionado";
});
contratoAccept.addEventListener("click", async () => {
  const idObrero = Number(contratoAccept.dataset.idObrero);
  if (!idObrero) {
    cerrarContratoModal();
    return;
  }
  const file = contratoFileInput.files?.[0];
  if (!file) {
    setFeedback("Debés seleccionar un archivo.", "error");
    return;
  }
  try {
    validarArchivoContrato(file);
  } catch (validationError) {
    setFeedback(validationError.message, "error");
    return;
  }
  const fechaVencimiento = document.getElementById("fecha_vencimiento").value;
  if (!fechaVencimiento) {
    setFeedback("Debés indicar una fecha de vencimiento.", "error");
    return;
  }
  contratoAccept.disabled = true;
  contratoAccept.textContent = "Subiendo...";
  try {
    await subirContratoObrero(idObrero, file, fechaVencimiento);
    contratoFileInput.value = "";
    document.getElementById("fecha_vencimiento").value = "";
    await cargarContratosObrero(idObrero);
    await cargarObreros();
    setFeedback("Contrato subido correctamente.", "success");
  } catch (error) {
    console.error(error);
    setFeedback(error.message || "No se pudo subir el contrato.", "error");
  } finally {
    contratoAccept.disabled = false;
    contratoAccept.textContent = "Subir contrato";
  }
});
paginationPrev.addEventListener("click", () => cambiarPagina(-1));
paginationNext.addEventListener("click", () => cambiarPagina(1));

openRegisterPanel.addEventListener("click", () => {
  resetForm();
  togglePanels(true);
});
cancelRegisterPanel.addEventListener("click", () => {
  if (obreroEnEdicion === null) {
    togglePanels(false);
    return;
  }
  resetForm();
  togglePanels(false);
  setFeedback("Edición cancelada.", "info");
});

obreroForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const payload = buildPayload();
  if (!payload) {
    return;
  }

  btnGuardar.disabled = true;
  btnGuardar.textContent = obreroEnEdicion ? "Actualizando..." : "Guardando...";

  try {
    if (apiBase && !csrfToken) {
      csrfToken = await obtenerCsrf();
    }

    const data = await guardarObrero(payload);
    paginaActual = 1;
    await cargarObreros();
    setFeedback(data.message || "Obrero guardado correctamente.", "success");
    resetForm();
    togglePanels(false);
  } catch (error) {
    console.error(error);
    setFeedback(error.message || "No se pudo guardar el obrero.", "error");
  } finally {
    btnGuardar.disabled = false;
    btnGuardar.textContent = "Guardar";
  }
});

searchObreros.addEventListener("input", (event) => {
  terminoBusqueda = event.target.value || "";
  paginaActual = 1;
  window.clearTimeout(busquedaTimeoutId);
  busquedaTimeoutId = window.setTimeout(() => {
    cargarObreros().catch((error) => {
      console.error(error);
      setFeedback(error.message || "No se pudieron cargar los obreros.", "error");
    });
  }, 200);
});

document.addEventListener("click", async (event) => {
  const button = event.target.closest("button[data-action]");
  if (!button) {
    return;
  }

  const idObrero = Number.parseInt(button.dataset.id, 10);
  if (!idObrero) {
    return;
  }

  if (button.dataset.action === "edit") {
    const obrero = obreros.find((item) => item.id_obrero === idObrero);
    if (obrero) {
      abrirConfirmacion({
        title: "Confirmar edición",
        message: `¿Querés cargar "${escapeHtml(obrero.nombre)} ${escapeHtml(obrero.apellido || "")}" en el formulario para editarlo?`,
        acceptLabel: "Editar",
        onAccept: async () => {
          fillForm(obrero);
          togglePanels(true);
          setFeedback(`Editando ${obrero.nombre} ${obrero.apellido || ""}.`.trim(), "info");
        },
      });
    }
    return;
  }

  if (button.dataset.action === "delete") {
    const obrero = obreros.find((item) => item.id_obrero === idObrero);
    if (!obrero) {
      return;
    }

    abrirConfirmacion({
      title: "Confirmar eliminación",
      message: `¿Eliminar al obrero "${escapeHtml(obrero.nombre)} ${escapeHtml(obrero.apellido || "")}"? Esta acción no se puede deshacer.`,
      acceptLabel: "Eliminar",
      onAccept: async () => {
        try {
          if (apiBase && !csrfToken) {
            csrfToken = await obtenerCsrf();
          }

          const data = await eliminarObrero(idObrero);
          if (obreroEnEdicion === idObrero) {
            resetForm();
            togglePanels(false);
          }
          await cargarObreros();
          setFeedback(data.message || "Obrero eliminado correctamente.", "success");
        } catch (error) {
          console.error(error);
          setFeedback(error.message || "No se pudo eliminar el obrero.", "error");
        }
      },
    });
    return;
  }

  if (button.dataset.action === "contrato") {
    event.stopPropagation();
    const nombre = button.dataset.nombre || "";
    await abrirModalContrato(idObrero, nombre);
    return;
  }
});

contratoCancel.addEventListener("click", () => {
  cerrarContratoModal();
});

document.addEventListener("click", async (event) => {
  const downloadBtn = event.target.closest("button[data-download-contrato]");
  if (downloadBtn) {
    event.stopPropagation();
    const idContrato = Number(downloadBtn.dataset.downloadContrato);
    if (idContrato) {
      await descargarContratoObrero(idContrato);
    }
    return;
  }

  const deleteBtn = event.target.closest("button[data-delete-contrato]");
  if (deleteBtn) {
    event.stopPropagation();
    const idContrato = Number(deleteBtn.dataset.deleteContrato);
    if (idContrato) {
      abrirConfirmacion({
        title: "Confirmar eliminación",
        message: "¿Eliminar este contrato? Esta acción no se puede deshacer.",
        acceptLabel: "Eliminar",
        onAccept: async () => {
          await eliminarContratoObrero(idContrato);
        },
      });
    }
    return;
  }

  const editBtn = event.target.closest("button[data-edit-contrato]");
  if (editBtn) {
    event.stopPropagation();
    abrirEditarFechaContrato(editBtn);
    return;
  }
});

inicializarVista().catch((error) => {
  console.error(error);
  setFeedback(error.message || "No se pudieron cargar los obreros.", "error");
});

async function inicializarVista() {
  setLoading(true);

  if (!apiBase && !isDesktopWebView) {
    setLoading(false);
    throw new Error(
      "Abrí esta pantalla desde navegador con PHP o desde la app de escritorio.",
    );
  }

  try {
    if (apiBase) {
      csrfToken = await obtenerCsrf();
    }
    await cargarObreros();
  } finally {
    setLoading(false);
  }
}

function togglePanels(showRegister) {
  panelObreros.classList.toggle("hidden", showRegister);
  panelRegistro.classList.toggle("hidden", !showRegister);
}

function buildPayload() {
  const payload = {
    id_obrero: obreroEnEdicion || undefined,
    nombre: leerCampo("nombre"),
    apellido: leerCampo("apellido"),
    documento: leerCampo("documento"),
    telefono: leerCampo("telefono"),
    fecha_contratacion: leerCampo("fecha_contratacion") || null,
    fecha_fin: leerCampo("fecha_fin") || null,
    cargo: leerCampo("cargo") || "Peón",
  };

  if (!payload.nombre || !payload.documento) {
    setFeedback("Nombre y documento son obligatorios.", "error");
    return null;
  }

  return payload;
}

function leerCampo(id) {
  return document.getElementById(id).value.trim();
}

async function guardarObrero(payload) {
  if (apiBase) {
    const response = await fetch(`${apiBase}/obreros.php`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRF-Token": csrfToken,
      },
      credentials: "include",
      body: JSON.stringify(payload),
    });

    const data = await parseJsonResponse(
      response,
      "No se pudo guardar el obrero.",
    );
    if (!response.ok) {
      throw new Error(data.error || "No se pudo guardar el obrero.");
    }

    return data;
  }

  return sendDesktopRequest("obreros_guardar", payload, "obreros_guardar_response");
}

async function eliminarObrero(idObrero) {
  if (apiBase) {
    const response = await fetch(`${apiBase}/obreros.php`, {
      method: "DELETE",
      headers: {
        "Content-Type": "application/json",
        "X-CSRF-Token": csrfToken,
      },
      credentials: "include",
      body: JSON.stringify({ id_obrero: idObrero }),
    });

    const data = await parseJsonResponse(
      response,
      "No se pudo eliminar el obrero.",
    );
    if (!response.ok) {
      throw new Error(data.error || "No se pudo eliminar el obrero.");
    }

    return data;
  }

  return sendDesktopRequest(
    "obreros_eliminar",
    { id_obrero: idObrero },
    "obreros_eliminar_response",
  );
}

function sendDesktopRequest(type, payload, responseType) {
  if (!isDesktopWebView) {
    return Promise.reject(
      new Error("El puente de escritorio no está disponible."),
    );
  }

  const requestId = `${type}-${Date.now()}-${Math.random().toString(36).slice(2)}`;

  return new Promise((resolve, reject) => {
    const timeoutId = window.setTimeout(() => {
      window.chrome.webview.removeEventListener("message", onMessage);
      reject(new Error("La aplicación de escritorio no respondió a tiempo."));
    }, 15000);

    function onMessage(event) {
      const data =
        typeof event.data === "string" ? JSON.parse(event.data) : event.data;
      if (data.type !== responseType || data.requestId !== requestId) {
        return;
      }

      window.clearTimeout(timeoutId);
      window.chrome.webview.removeEventListener("message", onMessage);

      if (!data.success) {
        reject(new Error(data.error || "Error de escritorio."));
        return;
      }

      resolve(data);
    }

    window.chrome.webview.addEventListener("message", onMessage);
    window.chrome.webview.postMessage(
      JSON.stringify({ type, requestId, ...payload }),
    );
  });
}

async function fetchJson(url, options) {
  const response = await fetch(url, {
    credentials: "include",
    ...options,
  });
  const data = await parseJsonResponse(response, "Error de servidor.");

  if (!response.ok) {
    throw new Error(data.error || "Error de servidor.");
  }

  return data;
}

async function obtenerCsrf() {
  const data = await fetchJson(`${apiBase}/csrf.php`);
  return data.token || "";
}

async function parseJsonResponse(response, fallbackMessage) {
  const text = await response.text();
  if (!text) {
    throw new Error(fallbackMessage);
  }

  try {
    return JSON.parse(text);
  } catch {
    throw new Error(fallbackMessage);
  }
}

async function cargarObreros() {
  const solicitudId = ++ultimaSolicitudListado;
  setLoading(true);

  try {
    let data;

    if (apiBase) {
      const params = new URLSearchParams({
        page: String(paginaActual),
        limit: String(OBREROS_POR_PAGINA),
        search: terminoBusqueda,
        filtro_contrato: filtroContrato,  // NUEVO: enviar filtro
      });
      data = await fetchJson(`${apiBase}/obreros.php?${params.toString()}`);
    } else {
      data = await sendDesktopRequest(
        "obreros_listar",
        {
          page: paginaActual,
          limit: OBREROS_POR_PAGINA,
          search: terminoBusqueda,
          filtro_contrato: filtroContrato,
        },
        "obreros_listar_response",
      );
    }

    if (solicitudId !== ultimaSolicitudListado) {
      return;
    }

    obreros = data.obreros || [];
    totalObreros = Number(data.total || 0);
    totalPaginas = Math.max(1, Number(data.total_pages || 1));
    paginaActual = Math.min(
      Math.max(1, Number(data.page || paginaActual)),
      totalPaginas,
    );
    renderObreros();
  } finally {
    if (solicitudId === ultimaSolicitudListado) {
      setLoading(false);
    }
  }
}

function renderObreros() {
  obreroTableBody.innerHTML = "";

  resultsCount.textContent = `${totalObreros} ${totalObreros === 1 ? "obrero" : "obreros"}`;
  tableWrap.classList.toggle("hidden", totalObreros === 0);
  emptyState.classList.toggle("hidden", totalObreros !== 0);
  pagination.classList.toggle("hidden", totalObreros === 0 || totalPaginas === 1);

  if (totalObreros === 0) {
    let mensaje = obtenerMensajeSinResultados(terminoBusqueda.trim());

    if (filtroContrato !== "todos") {
      const textosFiltro = {
        vencido: "contratos vencidos",
        por_vencer: "contratos por vencer (próximos 30 días)",
        vigente: "contratos vigentes"
      };

      mensaje = `No hay obreros con ${textosFiltro[filtroContrato] || filtroContrato}.`;
    }

    emptyStateMessage.textContent = mensaje;
    paginationInfo.textContent = "Mostrando 0-0 de 0 obreros";
    paginationPage.textContent = "Página 0 de 0";
    paginationPrev.disabled = true;
    paginationNext.disabled = true;
    return;
  }


  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0);


  obreros.forEach((obrero) => {

    const row = document.createElement("tr");

    let claseAlerta = "";


    // PRIORIZAR fecha_fin (fin de relación) sobre vencimiento (contrato)
    const fechaVenc = obrero.fecha_fin || obrero.vencimiento;

    if (fechaVenc && !String(fechaVenc).startsWith("0000")) {
      let fechaVencDate;

      if (fechaVenc.includes("/")) {
        const partesFecha = fechaVenc.split("/");
        fechaVencDate = new Date(
          Number(partesFecha[2]),
          Number(partesFecha[1]) - 1,
          Number(partesFecha[0])
        );
      } else if (fechaVenc.includes("-")) {
        const partesFecha = fechaVenc.split("-");
        fechaVencDate = new Date(
          Number(partesFecha[0]),
          Number(partesFecha[1]) - 1,
          Number(partesFecha[2])
        );
      } else {
        fechaVencDate = new Date(fechaVenc);
      }

      fechaVencDate.setHours(0, 0, 0, 0);
      const diffDays = Math.ceil((fechaVencDate - hoy) / (1000 * 60 * 60 * 24));

      if (diffDays < 0) {
        claseAlerta = "table-danger";
      } else if (diffDays <= 30) {
        claseAlerta = "table-warning";
      }
    }


    if (claseAlerta) {
      row.classList.add(claseAlerta);
    }



    row.innerHTML = `
      <td>
        <strong>${escapeHtml(obrero.nombre)}</strong>
        ${escapeHtml(obrero.apellido || "")}
      </td>

      <td>${escapeHtml(obrero.documento)}</td>

      <td>${escapeHtml(obrero.telefono || "—")}</td>

      <td>${formatDate(obrero.fecha_contratacion)}</td>

      <td>${formatDate(obrero.fecha_fin)}</td>

      <td>${escapeHtml(obrero.cargo || "Peón")}</td>

      <td>
        <div class="table-actions">

          <button 
            type="button" 
            class="action-btn edit" 
            data-action="edit" 
            data-id="${obrero.id_obrero}" 
            title="Editar obrero">
            <i class="fas fa-pen"></i>
          </button>


          <button 
            type="button" 
            class="action-btn delete" 
            data-action="delete" 
            data-id="${obrero.id_obrero}" 
            title="Eliminar obrero">
            <i class="fas fa-trash"></i>
          </button>


          <button 
            type="button" 
            class="action-btn" 
            style="background:#d88f2d;color:#fff;" 
            data-action="contrato" 
            data-id="${obrero.id_obrero}" 
            data-nombre="${escapeHtml(
              obrero.nombre + " " + (obrero.apellido || "")
            ).trim()}" 
            title="Subir contrato">

            <i class="fas fa-file-pdf"></i>

          </button>

        </div>
      </td>
    `;


    obreroTableBody.appendChild(row);

  });



  const desde =
    (paginaActual - 1) * OBREROS_POR_PAGINA + 1;


  const hasta =
    Math.min(
      paginaActual * OBREROS_POR_PAGINA,
      totalObreros
    );


  paginationInfo.textContent =
    `Mostrando ${desde}-${hasta} de ${totalObreros} ${
      totalObreros === 1 ? "obrero" : "obreros"
    }`;


  paginationPage.textContent =
    `Página ${paginaActual} de ${totalPaginas}`;


  paginationPrev.disabled = paginaActual === 1;

  paginationNext.disabled = paginaActual === totalPaginas;
}

async function cambiarPagina(direccion) {
  const nuevaPagina = paginaActual + direccion;
  if (nuevaPagina < 1 || nuevaPagina > totalPaginas) {
    return;
  }

  paginaActual = nuevaPagina;
  await cargarObreros();
}

function fillForm(obrero) {
  obreroEnEdicion = obrero.id_obrero;
  document.getElementById("id_obrero").value = obrero.id_obrero;
  document.getElementById("nombre").value = obrero.nombre || "";
  document.getElementById("apellido").value = obrero.apellido || "";
  document.getElementById("documento").value = obrero.documento || "";
  document.getElementById("telefono").value = obrero.telefono || "";
  document.getElementById("fecha_contratacion").value = obrero.fecha_contratacion || "";
  document.getElementById("fecha_fin").value = obrero.fecha_fin || "";
  document.getElementById("cargo").value = obrero.cargo || "Peón";
  formTitle.textContent = "Editar obrero";
  btnGuardar.textContent = "Guardar";
}

function resetForm() {
  obreroForm.reset();
  obreroEnEdicion = null;
  document.getElementById("id_obrero").value = "";
  formTitle.textContent = "Registrar obrero";
  btnGuardar.textContent = "Guardar";
}

function setLoading(isLoading) {
  loadingState.classList.toggle("hidden", !isLoading);
  if (isLoading) {
    tableWrap.classList.add("hidden");
    emptyState.classList.add("hidden");
    pagination.classList.add("hidden");
  }
}

function setFeedback(message, type = "info") {
  feedbackPanel.classList.remove(
    "hidden",
    "feedback-success",
    "feedback-error",
    "feedback-info",
  );
  feedbackPanel.classList.add(`feedback-${type}`);
  feedbackTitle.textContent =
    type === "error"
      ? "No se pudo completar la acción"
      : type === "success"
        ? "Operación completada"
        : "Atención";
  feedbackMessage.textContent = message;
}

function abrirConfirmacion({ title, message, acceptLabel, onAccept }) {
  confirmTitle.textContent = title;
  confirmMessage.textContent = message;
  confirmAccept.textContent = acceptLabel;
  confirmAction = onAccept;
  confirmModal.classList.remove("hidden");
}

function cerrarConfirmacion() {
  confirmModal.classList.add("hidden");
  confirmAction = null;
  confirmAccept.textContent = "Confirmar";
}

function ocultarFeedback() {
  feedbackPanel.classList.add("hidden");
}

function formatDate(value) {
  if (!value) {
    return "Sin fecha";
  }

  const [year, month, day] = value.split("-");
  if (!year || !month || !day || year === "0000") {
    return "Sin fecha";
  }

  return `${day}/${month}/${year}`;
}

function obtenerMensajeSinResultados(busqueda) {
  if (!obreros.length && busqueda === "") {
    return "No hay obreros registrados todavía.";
  }

  if (busqueda) {
    return "No se encontraron obreros para esa búsqueda.";
  }

  return "No hay obreros registrados todavía.";
}

function cerrarContratoModal() {
  contratoModal.classList.add("hidden");
  contratoAccept.dataset.idObrero = "";
  contratoFileInput.value = "";
  if (contratoFileName) contratoFileName.textContent = "Ningún archivo seleccionado";
  document.getElementById("fecha_vencimiento").value = "";
}

async function abrirModalContrato(idObrero, nombreObrero) {
  contratoAccept.dataset.idObrero = String(idObrero);
  contratoModalTitle.textContent = `Contratos de ${nombreObrero || "Obrero"}`;
  contratoFileInput.value = "";
  if (contratoFileName) contratoFileName.textContent = "Ningún archivo seleccionado";
  document.getElementById("fecha_vencimiento").value = "";
  contratoModal.classList.remove("hidden");
  await cargarContratosObrero(idObrero);
}

async function cargarContratosObrero(idObrero) {
  if (!contratoLista) return;
  contratoLista.innerHTML = '<p class="empty-hint">Cargando contratos...</p>';

  try {
    let data;
    if (apiBase) {
      data = await fetchJson(`${apiBase}/obreros.php?id_obrero_contratos=${idObrero}`);
    } else {
      data = await sendDesktopRequest(
        "obreros_contratos_listar",
        { id_obrero: idObrero },
        "obreros_contratos_listar_response"
      );
    }

    renderizarContratosObrero(data.contratos || []);
  } catch (error) {
    console.error("Error cargando contratos:", error);
    contratoLista.innerHTML = '<p class="empty-hint" style="color:#b54747;">No se pudieron cargar los contratos.</p>';
  }
}

function renderizarContratosObrero(contratos) {
  if (!contratoLista) return;

  if (!contratos.length) {
    contratoLista.innerHTML = '<p class="empty-hint">No hay contratos registrados para este obrero.</p>';
    return;
  }

  const hoy = new Date();
  hoy.setHours(0, 0, 0, 0);

  contratoLista.innerHTML = contratos.map((c) => {
    let estadoBadge = "";
    if (c.fecha_vencimiento) {
      const vDate = new Date(c.fecha_vencimiento + "T00:00:00");
      const diffDays = Math.ceil((vDate - hoy) / (1000 * 60 * 60 * 24));
      if (diffDays < 0) {
        estadoBadge = '<span class="alert-badge-tag vencido" style="font-size:10.5px;padding:2px 6px;">Vencido</span>';
      } else if (diffDays <= 30) {
        estadoBadge = '<span class="alert-badge-tag por_vencer" style="font-size:10.5px;padding:2px 6px;">Por vencer</span>';
      } else {
        estadoBadge = '<span class="kpi-badge badge-success" style="font-size:10.5px;padding:2px 6px;">Vigente</span>';
      }
    }

    return `
      <div class="contrato-item-row" data-id-contrato="${c.id_contrato_obrero}" style="display:flex;align-items:center;justify-content:space-between;padding:10px 14px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;margin-bottom:8px;gap:8px;">
        <div style="display:flex;align-items:center;gap:10px;min-width:0;flex:1;">
          <i class="fas fa-file-pdf" style="color:#b54747;font-size:20px;flex-shrink:0;"></i>
          <div style="min-width:0;">
            <div style="font-weight:600;font-size:13px;color:#1e293b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;" title="${escapeHtml(c.nombre_archivo || 'Contrato')}">${escapeHtml(c.nombre_archivo || 'Contrato')}</div>
            <div style="font-size:11.5px;color:#64748b;display:flex;align-items:center;gap:6px;margin-top:2px;">
              <span>Vence: ${formatDate(c.fecha_vencimiento)}</span>
              ${estadoBadge}
            </div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;">
          <button type="button" class="btn-icon" data-download-contrato="${c.id_contrato_obrero}" title="Descargar contrato" style="width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:6px;background:#ffffff;border:1px solid #cbd5e1;color:#334155;cursor:pointer;">
            <i class="fas fa-download"></i>
          </button>
          <button type="button" class="btn-icon" data-edit-contrato="${c.id_contrato_obrero}" data-fecha="${c.fecha_vencimiento || ''}" title="Editar fecha de vencimiento" style="width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:6px;background:#ffffff;border:1px solid #cbd5e1;color:#334155;cursor:pointer;">
            <i class="fas fa-pen"></i>
          </button>
          <button type="button" class="btn-icon" data-delete-contrato="${c.id_contrato_obrero}" title="Eliminar contrato" style="width:32px;height:32px;display:flex;align-items:center;justify-content:center;border-radius:6px;background:#fee2e2;border:1px solid #fca5a5;color:#dc2626;cursor:pointer;">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      </div>
    `;
  }).join("");
}

async function descargarContratoObrero(idContrato) {
  try {
    let data;
    if (apiBase) {
      const response = await fetch(`${apiBase}/obreros.php?descargar_contrato=${idContrato}`, {
        credentials: "include",
      });
      data = await parseJsonResponse(response, "No se pudo descargar el contrato.");
      if (!response.ok) throw new Error(data.error || "No se pudo descargar.");
    } else {
      data = await sendDesktopRequest(
        "obreros_contrato_descargar",
        { id_contrato_obrero: idContrato },
        "obreros_contrato_descargar_response"
      );
    }

    if (!data.contenido_base64) {
      throw new Error("No se pudo obtener el archivo del contrato.");
    }

    const blob = base64ToBlob(data.contenido_base64, data.tipo_contenido || "application/octet-stream");
    triggerBrowserDownload(blob, data.nombre_archivo || `contrato-${idContrato}`);
    setFeedback("Descarga iniciada.", "info");
  } catch (error) {
    console.error("Error descargando contrato:", error);
    setFeedback(error.message || "No se pudo descargar el contrato.", "error");
  }
}

async function eliminarContratoObrero(idContrato) {
  try {
    let data;
    if (apiBase) {
      if (!csrfToken) csrfToken = await obtenerCsrf();
      const response = await fetch(`${apiBase}/obreros.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-CSRF-Token": csrfToken,
        },
        credentials: "include",
        body: JSON.stringify({
          accion: "eliminar_contrato",
          id_contrato_obrero: idContrato,
        }),
      });
      data = await parseJsonResponse(response, "No se pudo eliminar el contrato.");
      if (!response.ok) throw new Error(data.error || "No se pudo eliminar.");
    } else {
      data = await sendDesktopRequest(
        "obreros_contrato_eliminar",
        { id_contrato_obrero: idContrato },
        "obreros_contrato_eliminar_response"
      );
    }

    const idObrero = Number(contratoAccept.dataset.idObrero);
    if (idObrero) {
      await cargarContratosObrero(idObrero);
    }
    await cargarObreros();
    setFeedback(data.message || "Contrato eliminado correctamente.", "success");
  } catch (error) {
    console.error("Error eliminando contrato:", error);
    setFeedback(error.message || "No se pudo eliminar el contrato.", "error");
  }
}

async function editarFechaContratoObrero(idContrato, fecha) {
  if (apiBase) {
    if (!csrfToken) csrfToken = await obtenerCsrf();
    const response = await fetch(`${apiBase}/obreros.php`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-CSRF-Token": csrfToken,
      },
      credentials: "include",
      body: JSON.stringify({
        accion: "editar_fecha_contrato",
        id_contrato_obrero: idContrato,
        fecha_vencimiento: fecha,
      }),
    });
    const data = await parseJsonResponse(response, "No se pudo actualizar la fecha.");
    if (!response.ok) throw new Error(data.error || "No se pudo actualizar la fecha.");
    return data;
  }

  return sendDesktopRequest(
    "obreros_contrato_editar_fecha",
    { id_contrato_obrero: idContrato, fecha_vencimiento: fecha },
    "obreros_contrato_editar_fecha_response"
  );
}

function abrirEditarFechaContrato(btn) {
  const idContrato = Number(btn.dataset.editContrato);
  if (!idContrato) return;

  const row = btn.closest(".contrato-item-row");
  if (!row) return;

  const fechaActual = btn.dataset.fecha || "";
  const originalHtml = row.innerHTML;

  row.innerHTML = `
    <div style="display:flex;align-items:center;gap:8px;width:100%;">
      <span style="font-size:12.5px;font-weight:600;color:#1e293b;white-space:nowrap;">Nueva fecha:</span>
      <input type="date" class="input input-nueva-fecha" value="${fechaActual}" style="padding:4px 8px;font-size:12.5px;height:32px;flex:1;" />
      <button type="button" class="btn-save btn-guardar-fecha" style="padding:4px 10px;font-size:12px;height:32px;">Guardar</button>
      <button type="button" class="btn-secondary btn-cancelar-fecha" style="padding:4px 10px;font-size:12px;height:32px;">Cancelar</button>
    </div>
  `;

  const inputFecha = row.querySelector(".input-nueva-fecha");
  const btnGuardarFecha = row.querySelector(".btn-guardar-fecha");
  const btnCancelarFecha = row.querySelector(".btn-cancelar-fecha");

  btnCancelarFecha.addEventListener("click", () => {
    row.innerHTML = originalHtml;
  });

  btnGuardarFecha.addEventListener("click", async () => {
    const nuevaFecha = inputFecha.value;
    if (!nuevaFecha) {
      setFeedback("Debés ingresar una fecha válida.", "error");
      return;
    }

    btnGuardarFecha.disabled = true;
    btnGuardarFecha.textContent = "...";

    try {
      await editarFechaContratoObrero(idContrato, nuevaFecha);
      const idObrero = Number(contratoAccept.dataset.idObrero);
      if (idObrero) {
        await cargarContratosObrero(idObrero);
      }
      await cargarObreros();
      setFeedback("Fecha de vencimiento actualizada.", "success");
    } catch (error) {
      console.error(error);
      setFeedback(error.message || "Error al actualizar la fecha.", "error");
      row.innerHTML = originalHtml;
    }
  });
}

function base64ToBlob(base64, mime) {
  const byteCharacters = atob(base64);
  const byteNumbers = new Array(byteCharacters.length);
  for (let i = 0; i < byteCharacters.length; i++) {
    byteNumbers[i] = byteCharacters.charCodeAt(i);
  }
  const byteArray = new Uint8Array(byteNumbers);
  return new Blob([byteArray], { type: mime });
}

function triggerBrowserDownload(blob, nombreArchivo) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = nombreArchivo;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

async function subirContratoObrero(idObrero, file, fechaVencimiento) {
  validarArchivoContrato(file);

  if (apiBase) {
    const formData = new FormData();
    formData.append("accion", "subir_contrato");
    formData.append("id_obrero", String(idObrero));
    formData.append("fecha_vencimiento", fechaVencimiento);
    formData.append("contrato", file);

    const response = await fetch(`${apiBase}/obreros.php`, {
      method: "POST",
      headers: {
        "X-CSRF-Token": csrfToken,
      },
      credentials: "include",
      body: formData,
    });

    const data = await parseJsonResponse(response, "No se pudo subir el contrato.");
    if (!response.ok) {
      throw new Error(data.error || "No se pudo subir el contrato.");
    }
    return data;
  }

  const contenidoBase64 = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(",")[1]);
    reader.onerror = () => reject(new Error("No se pudo leer el archivo."));
    reader.readAsDataURL(file);
  });

  return sendDesktopRequest(
    "obreros_subir_contrato",
    {
      id_obrero: idObrero,
      fecha_vencimiento: fechaVencimiento,
      nombre_archivo: file.name,
      contenido_base64: contenidoBase64,
    },
    "obreros_subir_contrato_response",
  );
}

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}