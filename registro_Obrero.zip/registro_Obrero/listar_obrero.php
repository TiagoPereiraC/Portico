<?php
require_once 'config/db.php';

header('Content-Type: application/json');

try {
    global $pdo;
    $stmt = $pdo->query("
        SELECT id_obrero as id, nombre, apellido, documento, telefono, fecha_contratacion as fecha
        FROM obreros
        WHERE activo = 1
        ORDER BY id_obrero DESC
    ");
    $obreros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($obreros);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al cargar: ' . $e->getMessage()]);
}
?>