<?php
require_once 'config/db.php';

header('Content-Type: application/json');

try {
    global $pdo;
    $stmt = $pdo->query("
        SELECT 
            o.id_obrero as id, 
            o.nombre, 
            o.apellido, 
            o.documento, 
            o.telefono, 
            o.fecha_contratacion as fecha,
            (
                SELECT fecha_vencimiento 
                FROM contrato_obrero 
                WHERE id_obrero = o.id_obrero 
                ORDER BY fecha_vencimiento DESC 
                LIMIT 1
            ) as vencimiento
        FROM obreros o
        WHERE o.activo = 1
        ORDER BY o.id_obrero DESC
    ");
    $obreros = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($obreros);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al cargar: ' . $e->getMessage()]);
}
?>