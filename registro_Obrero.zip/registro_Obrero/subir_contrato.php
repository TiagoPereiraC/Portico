<?php
require_once 'config/db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_obrero = $_POST['id_obrero'] ?? 0;
    $fecha_vencimiento = $_POST['fecha_vencimiento'] ?? null;

    if ($id_obrero <= 0) {
        $_SESSION['mensaje_error'] = "ID de obrero inválido.";
        header("Location: RegistrarObrero.php");
        exit;
    }

    if (!isset($_FILES['contrato']) || $_FILES['contrato']['error'] !== UPLOAD_ERR_OK) {
        $_SESSION['mensaje_error'] = "Error al subir el archivo.";
        header("Location: RegistrarObrero.php");
        exit;
    }

    $archivo_contenido = file_get_contents($_FILES['contrato']['tmp_name']);
    $nombre_original = $_FILES['contrato']['name'];

    try {
        $sql = "INSERT INTO contrato_obrero (archivo, id_obrero, fecha_vencimiento) VALUES (?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$archivo_contenido, $id_obrero, $fecha_vencimiento]);
        $_SESSION['mensaje_exito'] = "Contrato subido correctamente.";
    } catch (PDOException $e) {
        $_SESSION['mensaje_error'] = "Error al guardar: " . $e->getMessage();
    }

    header("Location: RegistrarObrero.php");
    exit;
} else {
    header("Location: RegistrarObrero.php");
    exit;
}
?>