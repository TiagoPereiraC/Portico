<?php
require_once 'config/db.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

$nombre = trim($data['nombre'] ?? '');
$apellido = trim($data['apellido'] ?? '');
$documento = trim($data['documento'] ?? '');
$telefono = trim($data['telefono'] ?? '');
$fecha = $data['fecha_contratacion'] ?? '';

if (empty($nombre) || empty($apellido) || empty($documento) || empty($telefono) || empty($fecha)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Todos los campos son obligatorios']);
    exit;
}

try {
    global $pdo;

    // Verificar si ya existe el documento
    $stmt = $pdo->prepare("SELECT id_obrero FROM obreros WHERE documento = ?");
    $stmt->execute([$documento]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Ya existe un obrero con ese documento']);
        exit;
    }

    $stmt = $pdo->prepare("
        INSERT INTO obreros (nombre, apellido, documento, telefono, fecha_contratacion, activo)
        VALUES (?, ?, ?, ?, ?, 1)
    ");
    $stmt->execute([$nombre, $apellido, $documento, $telefono, $fecha]);

    echo json_encode(['success' => true, 'message' => 'Obrero registrado correctamente']);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error al guardar: ' . $e->getMessage()]);
}
?>