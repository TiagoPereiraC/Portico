<?php
echo "Funciona";