<?php
require_once 'config/db.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

$id = $data['id'] ?? 0;
$nombre = trim($data['nombre'] ?? '');
$apellido = trim($data['apellido'] ?? '');
$documento = trim($data['documento'] ?? '');
$telefono = trim($data['telefono'] ?? '');
$fecha = $data['fecha_contratacion'] ?? '';

if (!$id || empty($nombre) || empty($apellido) || empty($documento) || empty($telefono) || empty($fecha)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Datos inválidos']);
    exit;
}

try {
    global $pdo;

    // Verificar que el documento no pertenezca a otro obrero
    $stmt = $pdo->prepare("SELECT id_obrero FROM obreros WHERE documento = ? AND id_obrero != ?");
    $stmt->execute([$documento, $id]);
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Ya existe otro obrero con ese documento']);
        exit;
    }

    $stmt = $pdo->prepare("
        UPDATE obreros
        SET nombre = ?, apellido = ?, documento = ?, telefono = ?, fecha_contratacion = ?
        WHERE id_obrero = ?
    ");
    $stmt->execute([$nombre, $apellido, $documento, $telefono, $fecha, $id]);

    echo json_encode(['success' => true, 'message' => 'Obrero actualizado correctamente']);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error al actualizar: ' . $e->getMessage()]);
}
?>