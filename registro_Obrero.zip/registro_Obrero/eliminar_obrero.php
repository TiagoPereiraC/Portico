<?php
require_once 'config/db.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'] ?? 0;

if (!$id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID inválido']);
    exit;
}

try {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE obreros SET activo = 0 WHERE id_obrero = ?");
    $stmt->execute([$id]);

    echo json_encode(['success' => true, 'message' => 'Obrero eliminado correctamente']);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error al eliminar: ' . $e->getMessage()]);
}
?>