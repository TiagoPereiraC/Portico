<?php
// Aquí puedes agregar lógica PHP si es necesario, por ejemplo:
// session_start();
// if (!isset($_SESSION['user_id'])) header('Location: Login.html');

// Mostrar mensajes de sesión (para éxito/error al subir contrato)
session_start();
$mensaje_exito = $_SESSION['mensaje_exito'] ?? '';
$mensaje_error = $_SESSION['mensaje_error'] ?? '';
unset($_SESSION['mensaje_exito'], $_SESSION['mensaje_error']);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Obreros - Pórtico</title>

<!-- ICONOS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<!-- Bootstrap 5 CSS (para el modal y alertas) -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
/* ========== TUS ESTILOS ORIGINALES (no los toco) ========== */
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

*, *::before, *::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}

:root {
  --bg:           #954043;
  --card-bg:      #e8e3df;
  --input-bg:     #f5f5f5;
  --input-border: #e0e0e0;
  --text-dark:    #666;
  --text-muted:   #888;
  --btn-bg:       #b54747;
  --btn-hover:    #9e3c3c;
  --accent:       #b54747;
  --input-shadow: 0 2px 8px rgba(0,0,0,.12);
}

body {
  background-color: var(--bg);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  font-family: 'Inter', sans-serif;
}

nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 24px;
  height: 140px;
  background-color: #fff;
  box-shadow: 0 2px 6px rgba(0,0,0,.12);
}

.logo-wrap img {
  width: 120px;
  height: auto;
}

.user-pill {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 14px;
  font-weight: 500;
  color: var(--text-dark);
}

.user-pill svg {
  width: 20px;
  height: 20px;
  fill: var(--text-muted);
}

.nav-dropdown {
  position: fixed;
  top: 155px;
  left: 16px;
  z-index: 1000;
}

.nav-menu-btn {
  display: flex;
  align-items: center;
  gap: 10px;
  background: #6b1f22;
  color: #fff;
  border: none;
  padding: 12px 22px;
  border-radius: 10px;
  font-size: 14px;
  font-family: 'Inter', sans-serif;
  cursor: pointer;
  box-shadow: 0 3px 10px rgba(0,0,0,0.25);
  transition: background 0.2s;
}

.nav-menu-btn:hover {
  background: #4f1618;
}

.nav-dropdown-menu {
  visibility: hidden;
  opacity: 0;
  position: absolute;
  top: 100%;
  left: 0;
  background: #fff;
  list-style: none;
  border-radius: 10px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.18);
  min-width: 240px;
  z-index: 1001;
  overflow: hidden;
  padding: 10px 0 6px 0;
  transition: opacity 0.18s ease, visibility 0.18s ease;
}

.nav-dropdown:hover .nav-dropdown-menu {
  visibility: visible;
  opacity: 1;
}

.nav-dropdown-menu li a {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 13px 22px;
  color: #555;
  text-decoration: none;
  font-size: 14px;
  font-family: 'Inter', sans-serif;
  transition: background 0.15s, color 0.15s;
}

.nav-dropdown-menu li a:hover,
.nav-dropdown-menu li a.active {
  background: #f5f0ef;
  color: #954043;
}

.nav-dropdown-menu li a i {
  width: 16px;
  text-align: center;
  color: #954043;
}

.nav-dropdown-menu li:last-child a {
  border-top: 1px solid #eee;
  color: #b54747;
}

main {
  flex: 1;
  padding: 48px 16px;
  display: flex;
  justify-content: center;
  align-items: flex-start;
}

.card {
  background: var(--card-bg);
  padding: 50px 45px;
  border-radius: 25px;
  width: min(100%, 980px);
  box-shadow: 0 8px 32px rgba(0,0,0,.18);
}

.panel-view.hidden {
  display: none;
}

.card h2 {
  text-align: center;
  font-size: 22px;
  font-weight: 600;
  color: var(--text-dark);
  margin-bottom: 20px;
}

.form-wrap {
  max-width: 480px;
  margin: 0 auto;
}

.grupo {
  margin-bottom: 18px;
}

.label {
  font-size: 13px;
  font-weight: bold;
  color: #444;
  margin-bottom: 6px;
  display: flex;
  align-items: center;
  gap: 8px;
}

.label i {
  color: var(--accent);
}

.input {
  width: 100%;
  padding: 14px;
  border: 1.5px solid var(--input-border);
  border-radius: 10px;
  background: var(--input-bg);
  font-size: 14px;
  box-shadow: var(--input-shadow);
  outline: none;
  transition: 0.2s;
}

.input:hover, .input:focus {
  border-color: var(--accent);
}

.fecha {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin: 15px 0 25px;
  font-size: 14px;
  color: #444;
}

.fecha input {
  padding: 10px;
  border: 1.5px solid var(--input-border);
  border-radius: 10px;
  background: var(--input-bg);
}

.btn {
  display: block;
  width: 100%;
  padding: 14px;
  border: none;
  border-radius: 10px;
  background: var(--btn-bg);
  color: white;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: 0.2s;
  text-align: center;
}

.btn:hover {
  background: var(--btn-hover);
  transform: scale(1.02);
}

.table-container {
  background: #fff;
  border-radius: 15px;
  padding: 15px;
  overflow-x: auto;
  margin-top: 15px;
}

.btn-new {
  display: inline-block;
  margin-bottom: 15px;
  background: var(--btn-bg);
  color: white;
  padding: 12px 16px;
  border-radius: 10px;
  font-size: 14px;
  font-weight: 500;
  border: none;
  cursor: pointer;
}

.btn-new i {
  margin-right: 6px;
}

.btn-new:hover {
  background: var(--btn-hover);
  transform: scale(1.03);
}

table {
  width: 100%;
  border-collapse: collapse;
}

thead {
  background-color: var(--accent);
  color: white;
}

th, td {
  padding: 12px;
  text-align: center;
  border-bottom: 1px solid var(--input-border);
}

tbody tr:nth-child(even) {
  background-color: #fafafa;
}

.btn-edit, .btn-delete, .btn-contrato {
  border: none;
  padding: 6px 10px;
  border-radius: 8px;
  cursor: pointer;
  margin: 0 3px;
}

.btn-edit {
  background: #3498db;
  color: white;
}

.btn-delete {
  background: #e74c3c;
  color: white;
}

.btn-contrato {
  background: #f39c12;
  color: white;
}

.btn-back {
  display: block;
  text-align: center;
  background: var(--text-muted);
  color: white;
  padding: 14px;
  border-radius: 10px;
  margin-top: 20px;
  text-decoration: none;
  font-size: 14px;
  font-weight: 500;
  transition: 0.2s;
}

.btn-back:hover {
  background: var(--text-dark);
}

/* Estilos para alertas de vencimiento */
.table-warning {
  background-color: #fff3cd !important;
}
.table-danger {
  background-color: #f8d7da !important;
}
</style>

</head>
<body>

<!-- MENÚ LATERAL -->
<div class="nav-dropdown">
  <button class="nav-menu-btn"><i class="fas fa-bars"></i> Menú</button>
  <ul class="nav-dropdown-menu">
    <li><a href="PanelInicio.html"><i class="fas fa-home"></i> Panel</a></li>
    <li><a href="RegistrarObra.html"><i class="fas fa-building"></i> Obras</a></li>
    <li><a href="RegistrarObrero.php" class="active"><i class="fas fa-helmet-safety"></i> Obreros</a></li>
    <li><a href="Asistencia.html"><i class="fas fa-clipboard-list"></i> Asistencia</a></li>
    <li><a href="Consultas.html"><i class="fas fa-chart-column"></i> Consultas</a></li>
    <li><a href="Login.html"><i class="fas fa-right-from-bracket"></i> Salir</a></li>
  </ul>
</div>

<nav>
  <div class="logo-wrap">
    <img src="assets/img/logo.png" alt="Pórtico Construcciones y Servicios">
  </div>
  <div class="user-pill">
    <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
      <path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z"/>
    </svg>
    Admin
  </div>
</nav>

<main>
  <div class="card">
    <!-- Mensajes de éxito/error -->
    <?php if($mensaje_exito): ?>
      <div class="alert alert-success"><?= htmlspecialchars($mensaje_exito) ?></div>
    <?php endif; ?>
    <?php if($mensaje_error): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($mensaje_error) ?></div>
    <?php endif; ?>

    <section id="panelObreros" class="panel-view active">
      <h2>Obreros</h2>
      <button type="button" class="btn-new" id="openRegisterPanel"><i class="fas fa-user-plus"></i> Registrar</button>
      <div class="table-container">
        <table>
          <thead>
            <tr><th>Nombre</th><th>DNI / Cédula</th><th>Teléfono</th><th>Fecha contratación</th><th>Acciones</th>
          </thead>
          <tbody id="obreroTableBody"></tbody>
        </table>
      </div>
      <a href="PanelInicio.html" class="btn-back">Volver</a>
    </section>

    <section id="panelRegistro" class="panel-view hidden">
      <div class="form-wrap">
        <h2 class="form-title">Registrar Obrero</h2>
        <form id="obreroForm">
          <div class="grupo"><div class="label">Nombre</div><input type="text" id="nombre" class="input" placeholder="Ej: Juan" required></div>
          <div class="grupo"><div class="label">Apellido</div><input type="text" id="apellido" class="input" placeholder="Ej: Carlos Mendoza" required></div>
          <div class="grupo"><div class="label">DNI / Cédula</div><input type="text" id="documento" class="input" placeholder="Ej: 5.123.456-7" required></div>
          <div class="grupo"><div class="label">Teléfono</div><input type="text" id="telefono" class="input" placeholder="Ej: 099 123 456" required></div>
          <div class="fecha"><label for="fecha_contratacion">Fecha Contratación</label><input type="date" id="fecha_contratacion" required></div>
          <div class="form-actions"><button type="submit" class="btn">Guardar</button><button type="button" class="btn-back" id="cancelRegisterPanel">Cancelar</button></div>
        </form>
      </div>
    </section>
  </div>
</main>

<!-- Modal para subir contrato -->
<div class="modal fade" id="modalContrato" tabindex="-1" aria-labelledby="modalContratoLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="subir_contrato.php" method="POST" enctype="multipart/form-data">
        <div class="modal-header">
          <h5 class="modal-title" id="modalContratoLabel">Subir Contrato de Obrero</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="id_obrero" id="modal_id_obrero">
          <div class="mb-3">
            <label for="contrato_file" class="form-label">Archivo (PDF, imagen, etc.)</label>
            <input class="form-control" type="file" name="contrato" id="contrato_file" required>
          </div>
          <div class="mb-3">
            <label for="fecha_vencimiento" class="form-label">Fecha de Vencimiento</label>
            <input class="form-control" type="date" name="fecha_vencimiento" id="fecha_vencimiento" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-primary">Guardar Contrato</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
const panelObreros = document.getElementById('panelObreros');
const panelRegistro = document.getElementById('panelRegistro');
const openRegisterPanel = document.getElementById('openRegisterPanel');
const cancelRegisterPanel = document.getElementById('cancelRegisterPanel');
const obreroForm = document.getElementById('obreroForm');
const tbody = document.getElementById('obreroTableBody');

let modoEdicion = false;
let idEditando = null;

function togglePanels(showRegister) {
    panelObreros.classList.toggle('hidden', showRegister);
    panelRegistro.classList.toggle('hidden', !showRegister);
}

function resetFormAndBack() {
    obreroForm.reset();
    const hoy = new Date().toISOString().slice(0,10);
    document.getElementById('fecha_contratacion').value = hoy;
    modoEdicion = false;
    idEditando = null;
    document.querySelector('#panelRegistro .form-title').textContent = 'Registrar Obrero';
    togglePanels(false);
    cargarObreros();
}

async function cargarObreros() {
    try {
        const response = await fetch('listar_obrero.php');
        if (!response.ok) throw new Error('Error al cargar');
        const obreros = await response.json();
        tbody.innerHTML = '';
        if (obreros.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5">No hay obreros registrados</td></tr>';
            return;
        }
        const hoy = new Date();
        hoy.setHours(0,0,0,0);
        obreros.forEach(ob => {
            const nombreCompleto = `${ob.nombre} ${ob.apellido}`;
            const row = document.createElement('tr');
            
            // Calcular días para vencimiento
            let claseAlerta = '';
            if (ob.vencimiento) {
                const fechaVenc = new Date(ob.vencimiento);
                const diffDays = Math.ceil((fechaVenc - hoy) / (1000 * 60 * 60 * 24));
                if (diffDays <= 30 && diffDays > 0) claseAlerta = 'table-warning';
                else if (diffDays <= 0) claseAlerta = 'table-danger';
            }
            row.className = claseAlerta;
            
            row.innerHTML = `
                <td>${escapeHtml(nombreCompleto)}</td>
                <td>${escapeHtml(ob.documento)}</td>
                <td>${escapeHtml(ob.telefono)}</td>
                <td>${ob.fecha}</td>
                <td>
                    <button class="btn-edit" data-id="${ob.id}"><i class="fas fa-pen"></i></button>
                    <button class="btn-delete" data-id="${ob.id}"><i class="fas fa-trash"></i></button>
                    <button class="btn-contrato" data-id="${ob.id}" data-nombre="${escapeHtml(nombreCompleto)}"><i class="fas fa-file-pdf"></i> Contrato</button>
                </td>
            `;
            tbody.appendChild(row);
        });
        
        // Eventos para editar, eliminar y contrato
        document.querySelectorAll('.btn-edit').forEach(btn => btn.addEventListener('click', () => editarObrero(btn.dataset.id)));
        document.querySelectorAll('.btn-delete').forEach(btn => btn.addEventListener('click', () => eliminarObrero(btn.dataset.id)));
        document.querySelectorAll('.btn-contrato').forEach(btn => {
            btn.addEventListener('click', () => {
                document.getElementById('modal_id_obrero').value = btn.dataset.id;
                document.getElementById('modalContratoLabel').innerText = `Subir Contrato de ${btn.dataset.nombre}`;
                new bootstrap.Modal(document.getElementById('modalContrato')).show();
            });
        });
    } catch(e) {
        console.error(e);
        alert('Error al cargar la lista de obreros');
    }
}

async function editarObrero(id) {
    try {
        const response = await fetch('listar_obrero.php');
        const obreros = await response.json();
        const ob = obreros.find(o => o.id == id);
        if (!ob) return;
        document.getElementById('nombre').value = ob.nombre;
        document.getElementById('apellido').value = ob.apellido;
        document.getElementById('documento').value = ob.documento;
        document.getElementById('telefono').value = ob.telefono;
        document.getElementById('fecha_contratacion').value = ob.fecha;
        modoEdicion = true;
        idEditando = id;
        document.querySelector('#panelRegistro .form-title').textContent = 'Editar Obrero';
        togglePanels(true);
    } catch(e) {
        alert('Error al obtener datos del obrero');
    }
}

async function eliminarObrero(id) {
    if (!confirm('¿Eliminar este obrero permanentemente?')) return;
    try {
        const response = await fetch('eliminar_obrero.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id })
        });
        const result = await response.json();
        if (result.success) {
            alert('Obrero eliminado');
            cargarObreros();
        } else {
            alert('Error: ' + result.message);
        }
    } catch(e) {
        alert('Error de conexión con el servidor');
    }
}

obreroForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = {
        nombre: document.getElementById('nombre').value.trim(),
        apellido: document.getElementById('apellido').value.trim(),
        documento: document.getElementById('documento').value.trim(),
        telefono: document.getElementById('telefono').value.trim(),
        fecha_contratacion: document.getElementById('fecha_contratacion').value
    };
    if (!formData.nombre || !formData.apellido || !formData.documento || !formData.telefono || !formData.fecha_contratacion) {
        alert('Todos los campos son obligatorios');
        return;
    }
    let url = 'guardar_obrero.php';
    let body = JSON.stringify(formData);
    if (modoEdicion && idEditando) {
        url = 'editar_obrero.php';
        body = JSON.stringify({ id: idEditando, ...formData });
    }
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: body
        });
        const result = await response.json();
        if (result.success) {
            alert(modoEdicion ? 'Obrero actualizado' : 'Obrero registrado');
            resetFormAndBack();
        } else {
            alert('Error: ' + result.message);
        }
    } catch(e) {
        alert('Error de conexión con el servidor');
    }
});

openRegisterPanel.addEventListener('click', () => {
    modoEdicion = false;
    idEditando = null;
    document.querySelector('#panelRegistro .form-title').textContent = 'Registrar Obrero';
    obreroForm.reset();
    const hoy = new Date().toISOString().slice(0,10);
    document.getElementById('fecha_contratacion').value = hoy;
    togglePanels(true);
});

cancelRegisterPanel.addEventListener('click', resetFormAndBack);

function escapeHtml(str) {
    if (!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

cargarObreros();
</script>
</body>
</html>